# شبكة اكسترا 5G اللاسلكية

A lightweight Arabic RTL promotional landing page for the Extra 5G wireless network launch.

## Run locally

The page has no package dependencies. From this directory, serve the files on the configured Preview port:

```bash
python3 -m http.server 3000 --bind 0.0.0.0
```

Then open `/` in a browser. The route manifest is available at `/manus-routes.json`.

## MikroTik Hotspot notes

- The current version is an announcement page only.
- It does not show a username, password, login button, logout action, or send authentication requests.
- It uses only local HTML, CSS, and JavaScript so it can be copied into a Hotspot page and remain useful without an external CDN.
- Tajawal weights 400, 500, 700, and 800 are bundled under `public/fonts/` and loaded locally as the primary Arabic font.
- Service links and WhatsApp are intentionally placeholders until real destinations are supplied.
- The JavaScript configuration object contains package/link boundaries for future content updates. A future MikroTik integration should be added as a separate adapter rather than mixing credential handling into the promotional UI.

## Content assumptions

No launch date, WhatsApp number, entertainment URL, or live-stream URL was supplied. The page therefore uses “opening soon” messaging and does not invent an exact date, discount, gift, or offer.
