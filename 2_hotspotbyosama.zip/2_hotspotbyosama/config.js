var jsonConfig={
  "network": {
    "nameP": "شبكة",
    "name": " تيربو ",
    "nameS": "5G",
    "phone": "739452490",
    "login_password": "empty",
    "host": "turbo.1sh.org",
    "https": 1
  },
  "about":{
    "btn":{
      "text":"739452490",
      "body":" عرض المزيد",
      "title":"للتواصل"
    },
    "content":[
      {"title":"الادارة","body":"739452490","href":{"action":"https://wa.me/967739452490","text":"وتساب"}},
      {"title":"الصيانة","body":"737608229","href":{"action":"https://wa.me/967737608229","text":"وتساب"}},
    ],
    "title":"عن الشبكة",
  },
  "apps":{
  "status":{
    "title":"صفحة المعلومات ",
  },

  "prices":{
      "content":[
  
        {
          "price": "100 ريال",
          "time": "4 ساعات",
          "transfer": "300  ميجا بايت",
          "validity": "2 أيام",
      },        
      {
          "price": "150 ريال",
          "time": "6 ساعات",
          "transfer": "450  ميجا بايت",
          "validity": "3 أيام",
      },        
      {
          "price": "250 ريال",
          "time": "12 ساعات",
          "transfer": "800  ميجا بايت",
          "validity": "6 أيام",
      },
      {
          "price": "500 ريال",
          "time": "30 ساعات",
          "transfer": "1800 ميجا بايت",
          "validity": "10 أيام",
      },
      {
        "price": "1000 ريال",
        "time": "مفتوح",
        "transfer": "4  جيجا بايت",
        "validity": "10 أيام",
      },
      {
        "price": "3000 ريال",
        "time": "مفتوح",
        "transfer": "12  جيجا بايت",
        "validity": "30 أيام",
      },
      {
        "price": "مجاني كبير",
        "time": "ساعتين",
        "transfer": "100  ميجا بايت",
        "validity": "يوم واحد",
      },
      {
        "price": "مجاني صغير",
        "time": "ساعة واحدة",
        "transfer": "60  ميجا بايت",
        "validity": "12 ساعة",
      }
      ],
      "title":"أسعار الكروت",
  },
  "markets":{
    "content":[
      {"title":"جميع البقالات المجاورة"},
      {"title":"جميع البقالات المجاورة"},
      {"title":"جميع البقالات المجاورة"},
      {"title":"جميع البقالات المجاورة"},
         
        ],
    "title":"نقاط البيع",
  },
},
"newsline":["  شبكة تيربو بحلتها الجديدة وقتك اطول و رصيدك اكتر معنا   "],
"sliders": [
{"src":"q.jpg","type":"img","text":"اضغط هنا للإستماع للقرآن الكريم مجاناً","href":"https://quran.ksu.edu.sa/index.php"},
  {"src":"sliders/1.jpg","type":"img","text":"استمتع باستراحة شبكتنا العملاقة"},
  ],
  "paw": {
          "title": "استخدام تطبيق الشبكة؟",
          "body": " يمكنك الحصول على مميزات عند فتح التطبيق مثل تسجيل الدخول التلقائي متابعة الرصيد اول باول و الحصول على تنبيهات عند اقتراب انتهاء الرصيد وغيرة من المزايا للتفاصيل اكثر قم بزيارة صفحة الخدمات"
    },
  "login": {
      "newsline": {
        "text": "تم تطوير الشبكه ورفع سرعة الخطوط .. وننوه لعملائنا الكرام انه تم اضافة خاصية تحديد السرعه الاختياري اسفل منطقة ادخال الكرت .. كما يمكنكم طلب جهاز منزلي للشبكة في حاله وجود اي ضعف باشارة الواي فاي عبر الاتصال بالرقم اعلاه وطلب الخدمة. نتمنى لكم قضاء اوقات ممتعه",
        "color": "#d91048"
      },
      "username": {
          "type": "tel",
          "only_numbers": 1,
          "upper_to_lower": 1,
          "only_alpha": 1,
          "rep_arabic_numbers": 1
        },
        "password": {
          "type": "hidden",
          "only_numbers": 0,
          "upper_to_lower": 1,
          "only_alpha": 1,
          "rep_arabic_numbers": 1
      },
      "domain":{
        "rad":"",
      },
      "speeds":{
        "SPD": [
      "256K/512K","256K/1M","256K/2M","256K/4M","256K/8M","2M/200M"
        ],
        "SPN": [
          " سرعة منخفضة للتوفير ",
          " 4G سرعة عادية ", 
          " سرعة عالية ",
          " 5G سرعة عالية جداً ",
          " سرعة  مفتوحة ",
          " سرعة مجنونة الرصيد بيطير ",
          ],
        "SD":1,
        "X":1,
    		"show":1,
        "alert":1,
      },
      "adv":['adv/1.jpg','adv/2.jpg','adv/3.jpg','adv/4.jpg','adv/1.jpg','adv/2.jpg','adv/3.jpg','adv4.jpg'],
    },
    "mobasher":"http://20.20.20.20:876/live",
    "estrahah":"http://20.20.20.20",
   "extra":{
      "izq":"",
      "tawk":"",
  },
  "block":{
    "block":1,
    "time": 4,
    "count": 10,
    "warn": 5,  
    "message":"<div><br /><br /><br /><h4>تحذير !! عدد محاولاتك الخاطئة اصبح {{na}} محاولاتك</h4><h4>اذا تجاوزت العدد المسموح للمحاولات {{count}} سيتم حظرك لمدة {{time}} دقائق</h4></div>"
  },
  "hjri":0,
  "colors":[
    {"id":"th0","color":"#660521",'--color-a':'#039b7a'},
    {"id":"th1","color":"#f57205",'--color-a':'#fb8d32'},
    {"id":"th2","color":"#ECC94B",'--color-a':'#0c7e78'},
    {"id":"th3","color":"#179848",'--color-a':'#3182ce'},
    {"id":"th4","color":"#2b6cb0",'--color-a':'#0d755f'},
    {"id":"th5","color":"#6b46c1",'--color-a':'#c37e37'},
    {"id":"th6","color":"#000000",'--color-a':'#6b46c1'},
  ],
  'css':'.im2::before,.im1::before{ content: "سرعة في النت" ; } .im3::before,.im4::before{ content: "وقت أستخدام أطول"; } .im5::before,.im6::before{ content: "سرعة في النت"; } .im7::before,.im8::before{ content: "رصيد انترنت اكثر"; }',
};
try {configInitFun(jsonConfig)} catch (e) {};
try {initForm(jsonConfig)} catch (e) {};
try {initCss(jsonConfig)} catch (e) {};
try {setTimeout(autoLogin,6500,jsonConfig);} catch (e) {};
function doNewLogin(ur){
if(ur.indexOf('domain=')>-1){
	var dm =ur.split('domain=')[1]
	dm="".concat(dm,'& &');
	dm=dm.split('&')[0].replace(' ','');
	var dm0="".concat(dm);
	if(dm0.length>1) {
	if(hotspotData&&hotspotData['locn'] && hotspotData['locn'].length>1){
		if (dm.indexOf("_EXTRA")>-1) {
			dm=dm.replace('_MAIN','');
		}
		if (dm.indexOf("_EXTRA")>-1) {
			dm=dm.replace('_EXTRA','');
		}

		if (dm.indexOf(hotspotData['locn'])==-1) {
			dm=dm+"_"+hotspotData['locn'];
		}
	if (dm.indexOf('OFF_OFF')>-1) {
		dm=dm.replace('OFF_OFF','OFF');
	}
	if (dm.indexOf('k')>-1) {
		dm=dm.replace('k','K');
		dm=dm.replace('k','K');
		dm=dm.replace('k','K');
	}
	if (dm.indexOf('m')>-1) {
		dm=dm.replace('m','M');
		dm=dm.replace('m','M');
		dm=dm.replace('m','M');
	}
}
ur=ur.replace(dm0,dm);
}
}
return xmlFetch(ur,{}).then(function(res){
return res.json().then(function(res2){
if(res2&&res2['dom']&&res2['dom'].indexOf("_MAIN")>-1){res2['dom']=res2['dom'].replace('_MAIN','');};
if(res2&&res2['dom']&&res2['dom'].indexOf("_EXTRA")>-1){res2['dom']=res2['dom'].replace('_EXTRA','');};
hotspotData = res2;
return res2;
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}
