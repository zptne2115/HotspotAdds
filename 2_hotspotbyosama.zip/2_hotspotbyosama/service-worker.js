const CACHE_VERSION = 26;
const CACHE_NAME = "ca".concat("-v", CACHE_VERSION);
const FILES_TO_CACHE = [
  '/css.fonts.v10.css',
  '/css.style.v10.css',
  '/css.color.v10.css',
  '/css.extra.v10.css',
  '/js.polyfill.v10.js',
  '/js.storage.v10.js',
  '/js.app.v10.js',
  '/js.main.v10.js',
  '/js.extra.v10.js',
  '/favicon.svg',
  '/favicon.ico',
];
self.addEventListener("install", function (event) {
  event.waitUntil(caches.open(CACHE_NAME).then(function(cache){
    try{return cache.addAll(FILES_TO_CACHE).catch(function(){return self.skipWaiting()});}catch(e){}
    return self.skipWaiting();
}).catch(function(){return self.skipWaiting()}));
});
// self.addEventListener("activate", function(event) {
//   function clearCashe(cacheNames,cacheAllowlist){return Promise.all(cacheNames.map(function(cacheName){if (!cacheAllowlist.includes(cacheName)) {return caches.delete(cacheName);};return undefined;}))}
//   event.waitUntil(caches.keys().then(function(cacheNames){clearCashe(cacheNames,CACHE_NAME)
//   }));
// });
