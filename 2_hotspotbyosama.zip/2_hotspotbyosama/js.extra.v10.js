var osTheme=[
{"id":"th0","color":"#660521",'--color-a':'#039b7a'},
{"id":"th1","color":"#f57205",'--color-a':'#82039b'},
{"id":"th2","color":"#ECC94B",'--color-a':'#0c7e78'},
{"id":"th3","color":"#179848",'--color-a':'#5331ce'},
{"id":"th4","color":"#2b6cb0",'--color-a':'#1fb789'},
{"id":"th5","color":"#6b46c1",'--color-a':'#c37e37'},
];
function loadNewsLines(n){
var news=document.getElementById("newsline");
if(news&&n&&n!=""){
var ht=news.innerHTML;
if(typeof n == "object"){
var txt="";
for (var i in n) {
var e =n[i];
var t=(e.length/5).toFixed(1);
if(t<20){t=20}
txt+=ht.replace('10s',t+'s').replace('10s',t+'s');
txt=fillMustache(txt,{"text":e});
}
news.innerHTML=txt;
} else{
var e=news.innerHTML;
var t=(e.length/5).toFixed(1);
if(t<20){t=20}
e=ht.replace('10s',t+'s').replace('10s',t+'s');
news.innerHTML=fillMustache(e,{"text":n});
}
news.style.display='block';
}}
function loadSliders(s){
var slis=document.getElementById("sliders");
if(slis&&isThisArr(s)&&s.length>0){
var sli=document.querySelector('.slides');
s&&s.forEach(function(e){
var a='/';
if('file:'===window.location.protocol){a=''}
if(e&&e.href&&!e.href.startsWith('http')&&!e.href.startsWith('/')&&!e.href.startsWith('.')){e.href=a+e.href;}
osamaSliderNew(e,sli);
});
setTimeout(sliderStart,1000);
slis.style.display='block';
}}
function osamaloadType(t , a, b, c) {
try {
if (!document.querySelector(t + '[src="' + a + '"]')) {
var h = (document.head||document.body||document.getElementsByTagName("script")[0].parentElement), d = document.createElement(t);
d.setAttribute("style","display:none;");
d.src = a;
void 0 !== b && (d.onreadystatechange = b, d.onload = b , d.onerror=(c||function(){})); h.appendChild(d)
} else { 
b&&b(a);
}} catch (error) {
c&&c();
}};
function osamaSliderNew(e,sli){
var ty=e.type;
var te=e.text;
var ts=e.src||'';
var hr=e.href;
var el=document.createElement('figure');
var elhref=document.createElement('a');
var elhref2=document.createElement('a');
el.className='animated';
var elm;
if(ty&&ty=='video'){
elm=document.createElement('video');
elm.setAttribute('onclick','if(this.paused){this.play()}else{this.pause()}');
elm.setAttribute('controls','');
elm.setAttribute('autoplay','');
elmsor=document.createElement('source');
elmsor.setAttribute('src',ts);
elmsor.setAttribute('type','video/'.concat(getLast(ts.split('.'))));
elm.appendChild(elmsor);
} else if(ty&&ty=='text'){
elm=document.createElement('div');
} else{
elm=document.createElement('img');
}
elm.setAttribute('width','350');
elm.src=ts;
elm.setAttribute('loading',"lazy");
if(typeof elm.onerror !="undefined"){elm.onerror=function(e){var el=e.target||this;(el.parentElement.tagName=='FIGURE'&&el.parentElement.remove()||(el.parentElement.parentElement.tagName=='FIGURE'&&el.parentElement.parentElement.remove()))}} else{elm.setAttribute("onerror","this.parentElement.tagName=='FIGURE'&&this.parentElement.remove()||this.parentElement.parentElement.tagName=='FIGURE'&&this.parentElement.parentElement.remove()");}
elm.setAttribute('href',hr);
if(hr&&hr.length){
elhref.href=hr;
elhref2.href=hr;
elhref.setAttribute('target',"_blank")
elhref2.setAttribute('target',"_blank")
elhref.setAttribute('rel',"noopener noreferrer")
elhref2.setAttribute('rel',"noopener noreferrer")
}
var elmt=document.createElement('figcaption');
elmt.innerText=te||"";
elhref.appendChild(elmt);
elhref2.appendChild(elm);
el.appendChild(elhref2);
el.appendChild(elhref);
sli.appendChild(el);
var slis=document.getElementById("sliders");
slis.style.display='block';
}

function osamaSliderFolderFetch(i, p1, p2,t) {
var url = p1 + i + p2;
if (typeof i != "number" || isNaN(i)) { return; };
if (i > 8) { return; };
var sli=document.querySelector('.slides');
var s=allSliders.some(function(v,i){return (v&&v.src&&v.src==url)});
if(!s&&url!=""){
osamaloadType(t,url, function (e) {
osamaSliderNew({"src":url,"title":"",href:"",type:t},sli);
osamaSliderFolderFetch((i*1 + 1), p1, p2,t);
}, function (e) {
})
} else{
osamaSliderFolderFetch((i*1 + 1), p1, p2,t);
}}
function osamaSliderFolder() {
var a='/';
if('file:'===window.location.protocol){a=''};
try {osamaSliderFolderFetch(1, a+'sliders/', '.mp4', 'video'); } catch (error) { }
try {osamaSliderFolderFetch(1, a+'sliders/', '.jpg','img');} catch (error) {}
try {osamaSliderFolderFetch(1, a+'sliders/', '.jpeg','img');} catch (error) {}
try {osamaSliderFolderFetch(1, a+'sliders/', '.png', 'img');} catch (error) { }
try {osamaSliderFolderFetch(1, a+'sliders/', '.webm', 'video');} catch (error) { }
try {osamaSliderFolderFetch(1, a+'sliders/', '.ogg', 'video');} catch (error) { }
setTimeout(sliderStart, 5000);
setTimeout(sliderStart, 10000);
setTimeout(function(){
    var sli=document.querySelectorAll('.slides figure');
    if(void 0==sli||sli.length===0){
        document.getElementById('sliders').style.display='none';
    }    
},2000)
}
function isThisObj(e){if("object"==typeof e&&e!=null){var n=Object.prototype&&Object.prototype.toString&&Object.prototype.toString.call(e).slice(8,-1);if(n&&n==='Object'){if(e.constructor){var n = e.constructor.name;if (n === "Map" || n === "Set"){return false};return true};};if(e.hasOwnProperty&&e.hasOwnProperty('length')){
var c=false;try{if(Array&&typeof Array.isArray=== 'function'&&Array.isArray(e)){return false};c=(typeof e.toString==='function'&&e.toString()==='[object Object]')||String(e)==='[object Object]'}catch(e){};if(c){return true}else{return false}}else{return true}};return false;}
function isThisArr(e){if("object"==typeof e&&e!=null){var n=Object.prototype&&Object.prototype.toString&&Object.prototype.toString.call(e).slice(8,-1);if (n&&n==='Array'){return true};if (e.constructor){var n = e.constructor.name;if (n === "Map" || n === "Set"){return true};if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)){return true};};
if(Array&&typeof Array.isArray=== 'function'&&Array.isArray(e)){return true}};return false}
function isNull(a){var t=typeof a;return (t=== 'undefined' || (t === 'object' && a==null) || null==a)};
function isEmStr(a){var t=typeof a;return (t=== 'undefined' || (t === 'object' && a==null) || null==a || a==='');};
function isObj(e){return "object"==typeof e&&e!=null}
function isObj1(a,b){return isObj(a)&&("undefined"==typeof a[b]&&a[b]==null)}
function isObj2(a,b){return isObj(a)&&isObj(a[b])}
function isObj3(a,b,c){return isObj(a)&&isObj(a[b])&&isObj(a[b][c])}
function isArr(e){if (Array.isArray){return "object"==typeof e&&e!=null&&Array.isArray(e)}else{return "object"==typeof e&&e!=null&&"number"==typeof e.length}}
function isUnd(e){return ("undefined"==typeof e||e==null)}
function isStr(e){return ("string"==typeof e)}
function isNum(a){if(typeof a!='string'&&typeof a!='number'){return false};var e="".concat(a);e=e.replace(/\s+|\n+|\r+|\t+/g,"");if(e.indexOf('.')>-1){e=parseFloat(e)}else{e=parseInt(e)};return isNaN(e)?false:true;}
function isEmpty(e){if(isArr(e)){return (e.length==0)};if(isStr(e)){return e==""};if(isObj(e)){var a=Object.keys(e);return a&&(a.length==0)};if(isNum(e)){return false};return true}
function toStr(e,b){if(typeof a!='string'&&typeof a!='number'){return b};return "".concat(e);}
function toNum(a,b){if(typeof a!='string'&&typeof a!='number'){return b};var e="".concat(a);e=e.replace(/\s+|\n+|\r+|\t+/g,"");if(e.indexOf('.')>-1){e=parseFloat(e)}else{e=parseInt(e)};return isNaN(e)?b:e;}
function toLenth(e){if(isArr(e)){return e.length};if(isStr(e)){return e.length};if(isObj(e)){if (Object.keys){var a=Object.keys(e);return a.length};var j=0;for (var i in e){j++};return j};return 0}
function getLast(e){if(e.length<1){return []};return e[e.length-1]}
function rgbToHsl(r, g, b) {
r /= 255; g /= 255; b /= 255;
var max = Math.max(r, g, b), min = Math.min(r, g, b);
var h, s, l = (max + min) / 2;
if (max === min) {
h = s = 0; 
} else {
var d = max - min;
s = l > 0.5 ?( d / (2 - max - min)) : (d / (max + min));
switch (max) {
case r: h = (g - b) / d + (g < b ? 6 : 0); break;
case g: h = (b - r) / d + 2; break;
case b: h = (r - g) / d + 4; break;
}
h /= 6;
}
return { h: h, s: s, l: l };
}
function hexToRgb(hex) {
hex = hex.replace(/^#/, '');
if (hex.length === 3) {
var hex2=hex.split('');
hex = hex2[0]+hex2[0]+hex2[1]+hex2[1]+hex2[2]+hex2[2];
}
var bigint = parseInt(hex, 16);
return {
r: (bigint >> 16) & 255,
g: (bigint >> 8) & 255,
b: bigint & 255
};
}

function hslToRgb(h, s, l) {
var r, g, b;
if (s === 0) {
r = g = b = l; 
} else {
function hue2rgb(p, q, t) {
if (t < 0) t += 1;
if (t > 1) t -= 1;
if (t < 1/6) return p + (q - p) * 6 * t;
if (t < 1/2) return q;
if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
return p;
}
var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
var p = 2 * l - q;
r = hue2rgb(p, q, h + 1/3);
g = hue2rgb(p, q, h);
b = hue2rgb(p, q, h - 1/3);
}
return {
r: Math.round(r * 255),
g: Math.round(g * 255),
b: Math.round(b * 255)
};
}
function to2str(a) {
if(a.length<2){a='0'.concat(a)};
return a;
}
function rgbToHex(r, g, b) {
return "#" + to2str(r.toString(16))+to2str(g.toString(16))+to2str(b.toString(16));    
}
function generateColorScale(baseColor,th) {
var rgb = hexToRgb(baseColor);
var hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
var output = '';
var output2 = '';
var oth={
'th0':'--color-a: #039b7a;',
'th1':'--color-a: #82039b;',
'th2':'--color-a: #0c7e78;',
'th3':'--color-a:rgb(83, 49, 206);',
'th4':'--color-a:rgb(31, 183, 137);',
'th5':'--color-a: #c37e37;',
'th6':'--color-a: #6b46c1;',
'th7':'--color-a: #3182ce;',
}
if(osTheme&&osTheme[0]&&osTheme[0]['--color-a']){osTheme.forEach(function(a){if(a['--color-a']){oth[a.id]='--color-a:'+a['--color-a']+';\n'}})}
for (var i = 0; i < 10; i++) {
var lightness = 0.95 - i * 0.09; 
var lightness2 =1 - (i * 0.05); 
var newRgb = hslToRgb(hsl.h, hsl.s, lightness);
var hex = rgbToHex(newRgb.r, newRgb.g, newRgb.b);
var newRgb2 = hslToRgb(hsl.h, hsl.s, lightness2);
var hex2 = rgbToHex(newRgb.r, newRgb.g, newRgb.b);
if(i==0){
output2 += '--color-text: #ffffff;\n';
}
if(i==1){
output2 += '--color-icon: ' + rgbToHex(newRgb.g, newRgb.r, newRgb.b) + ';\n';
}
if(i==3){
output2 += '--color-wr: ' + rgbToHex(newRgb.g, newRgb.r, newRgb.b) + ';\n';
}
if(i==5){
output2 += '--color-inv: ' + rgbToHex(newRgb.b, newRgb.r, newRgb.g) + ';\n';
}
if(i==6){
output2 += '--color-bt: ' + rgbToHex(newRgb.b, newRgb.g, newRgb.r) + ';\n';
}
if(i==7){
output2 += '--color-bg: ' + rgbToHex(newRgb.b, newRgb.g, newRgb.r) + ';\n';
if(th&&oth[th]){
output2 +=oth[th]
}else{
output2 += '--color-a: ' + rgbToHex(newRgb2.g, newRgb2.r, newRgb2.g) + ';\n';
}}
output += '--color-' + i + ': ' + hex + ';\n';
}
var c=output+output2;
if(th){
c= 'body[theme="'+th+'"],.'+th+' {'+c+'background: var(--color-5); background: -webkit-linear-gradient(225deg,var(--color-3),25%,var(--color-7),55%,var(--color-9),85%,#000); background: -moz-linear-gradient(225deg,var(--color-3),25%,var(--color-7),55%,var(--color-9),85%,#000); background: -o-linear-gradient(225deg,var(--color-3),25%,'+
'var(--color-7),55%,var(--color-9),85%,#000); background: linear-gradient(225deg,var(--color-2),25%,var(--color-6),55%,var(--color-9),80%,#000);}';
} else{
c= ':root{'+c+'background: var(--color-5); background: -webkit-linear-gradient(225deg,var(--color-3),25%,var(--color-7),55%,var(--color-9),85%,#000); background: -moz-linear-gradient(225deg,var(--color-3),25%,var(--color-7),55%,var(--color-9),85%,#000); background: -o-linear-gradient(225deg,var(--color-3),25%,var(--color-7),55%,var(--color-9),'+
'85%,#000); background: linear-gradient(225deg,var(--color-2),25%,var(--color-6),55%,var(--color-9),80%,#000);}';
}
return c;
}
var extraConfig={};
var extraFound={};
var extraError=500;
var extraErrorInterval;
function osamaRepAll(a,b,c){if(a.indexOf(b)>-1){var d=a.split();for(var i=0;i<d.length;i++){if(a.indexOf(b)>-1){a=a.replace(b,c);}}};return a;}
function osamaDecodeAr(o, esc) {esc=esc||false;if (typeof o === 'undefined'){return o;};o=o.toString();try {if ((/^([0-9A-Za-z]{3,15}[+]){1,20}[0-9A-Za-z]{3,15}$/gi).test(o) || (/not[+]found/gi).test(o) || esc) { o=o.split('+').join(" ") };if ((/[&][aglmopqstu]{2,5}[;]/gi).test(o)) { o=osamaConvertHTML(o) };if ((/[&][#][0-9A-F][0-9A-F][;]/gi).test(o)) {
o=osamaConvertHTML2(o) };if ((/[%][7-9A-F][0-9A-F]/gi).test(o)) { o=osamaDecodeAr2(o) };} catch (er) {
o=o.split('+').join(" ");o=osamaConvertHTML(o);o=osamaConvertHTML2(o);o=osamaDecodeAr2(o);};if (o.indexOf("%") === -1) { return o;};str=o.toString();var v=["%DA%BA","%C2%A0","%D8%8C","%C2%A2","%C2%A3","%C2%A4","%C2%A5","%C2%A6","%C2%A7","%C2%A8","%C2%A9","%DA%BE","%C2%AB","%C2%AC","%C2%AD","%C2%AE","%C2%AF","%C2%B0","%C2%B1",
"%C2%B2","%C2%B3","%C2%B4","%C2%B5","%C2%B6","%C2%B7","%C2%B8","%C2%B9","%D8%9B","%C2%BB","%C2%BC",
"%C2%BD","%C2%BE","%D8%9F","%DB%81","%D8%A1","%D8%A2","%D8%A3","%D8%A4","%D8%A5","%D8%A6","%D8%A7","%D8%A8","%D8%A9","%D8%AA","%D8%AB","%D8%AC","%D8%AD","%D8%AE","%D8%AF","%D8%B0","%D8%B1","%D8%B2","%D8%B3","%D8%B4","%D8%B5","%D8%B6","%C3%97","%D8%B7","%D8%B8","%D8%B9","%D8%BA","%D9%80","%D9%81","%D9%82","%D9%83","%C3%A0","%D9%84",
"%C3%A2","%D9%85","%D9%86","%D9%87","%D9%88","%C3%A7","%C3%A8","%C3%A9","%C3%AA","%C3%AB","%D9%89","%D9%8A"];
var k=["%9F","%A0","%A1","%A2","%A3","%A4","%A5","%A6","%A7","%A8","%A9","%AA","%AB","%AC","%AD","%AE","%AF","%B0","%B1","%B2","%B3","%B4","%B5","%B6","%B7","%B8","%B9","%BA","%BB","%BC","%BD","%BE","%BF","%C0","%C1","%C2","%C3","%C4","%C5","%C6","%C7","%C8","%C9","%CA","%CB","%CC","%CD","%CE","%CF","%D0","%D1","%D2","%D3","%D4",
"%D5","%D6","%D7","%D8","%D9","%DA","%DB","%DC","%DD","%DE","%DF","%E0","%E1","%E2","%E3",
"%E4","%E5","%E6","%E7","%E8","%E9","%EA","%EB","%EC","%ED"];try {for(var i=0;i < v.length;i++){if (str.indexOf(v[i]) > -1){str=str.split(v[i]).join(decodeURIComponent(v[i]));};};} catch (er) { };try { for (var i=0;i < v.length;i++) { if (str.indexOf(k[i]) > -1) { str=str.split(k[i]).join(decodeURIComponent(v[i]));};};} catch (er) { };
try { if (str.indexOf("%") > -1) { str=decodeURIComponent(str);} } catch (er) { };return str;};
function osamaDecodeAr3(o) {var z=[],out=o.toString();if (out.includes("%")&&(/[%][7-9A-F][0-9A-F]/gi).test(out)) { z=out.split('%');for (var i in z) {var a =z[i];try { if ((/[7-9A-F][0-9A-F]/gi).test(a)&&a.length===2&&out.includes('%'.concat(a))) {var bytes=[];bytes.push(parseInt(a.toUpperCase(), 16));var zz=a;
try{zz=((new TextDecoder("windows-1256")).decode((new Uint8Array(bytes)))).toString();
out=out.replace('%'.concat(a),zz);}catch(err){ };}else{ } } catch (e) { }};};return out;};
function osamaDecodeAr2(o) {if ((o.toString()).includes("%")) {try {o=o.replaceAll(/%[0-9A-F][0-9A-F]/gi, function (a) { var bytes=[];bytes.push(parseInt(a.replace('%', ''), 16));var z=a;try{z=((new TextDecoder("windows-1256")).decode((new Uint8Array(bytes)))).toString();}catch(err){ };return z;});} catch (e) {return osamaDecodeAr3(o);}};return o;};
function osamaConvertHTML(str) {try{var symbols={ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&apos;" };for (var symbol in symbols){if (str.indexOf(symbol) >= 0) { str=str.split(symbol).join(symbols[symbol]);} } return str;} catch (e) { };return str };
function osamaConvertHTML(str) {try{var symbols={ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&apos;" };for (var symbol in symbols) { if (str.indexOf(symbol) >= 0) { str=str.split(symbol).join(symbols[symbol]);} } return str;} catch (e) { };return str };
function osamaConvertHTML2(o) {if((o.toString()).includes("&#")) {try { o=o.replaceAll(/[&][#][0-9A-F][0-9A-F][;]/gi, function (a) { return String.fromCharCode(parseInt(a.replace('&#', '').replace(';', ''), 16));});} catch (e) { };};return o;};
function osamaDecode(obj, esc) {esc=esc||false;if (typeof obj === 'object') { for (var i in obj) { if (typeof obj[i] == 'object') { obj[i]=osamaDecode(obj[i], esc);} else { obj[i]=osamaDecodeAr(obj[i], esc);};};} else { return osamaDecodeAr(obj, esc);};return obj;};
function decodeResponse(res){if (typeof res === "object") { for (var k in res) { try { res[k]=osamaDecode(res[k], !0) } catch (e) { } };} else{res=osamaDecode(res);} return res;};
function isEqals(a1,a2){var a="".concat(a1||'');var b="".concat(a2||'');if(a!=""&&b!=""){return a.toLowerCase()===b.toLowerCase();};return false}
function doLoadExtra(a){a=osamaDecode(a,true);
var b=JSON.stringify(a);if(typeof extraFound[b] == "undefined"){extraFound[b]=1;
for(var i in a){var n1="",n2="";var n="".concat(i);if(n.indexOf('.')>-1){n1=n.split('.')[0];n2=n.split('.')[1]};
if (a[i]&&a[i]!=""){if(typeof a[i]==="object"&& (a[i].ip||a[i].ips||a[i].mac||a[i].username||a[i].macs||a[i].active||a[i].server)){var hotD=osamaDecode(hotspotData,true);
if(
(a[i]['ip']&&isEqals(a[i]['ip'],hotD.ip))
||(a[i]['mac']&&isEqals(a[i]['mac'],hotD.mac))
||(a[i]['username']&&isEqals(a[i]['username'],hotD.usr))
||(a[i]['active']&&isEqals(a[i]['active'],hotD.lin))
||(a[i]['server']&&isEqals(a[i]['server'],hotD.sern))
||(a[i]['ips']&&hotD.ip.startsWith(a[i]['ips']))
||(a[i]['macs']&&(hotD.mac.toLowerCase()).startsWith(a[i]['macs'].toLowerCase()))
){
if (window[n]){window[i](a[i])}else if (window[n1]&&window[n1][n2]){window[n1][n2](a[i])}} else{
}} else{
if (window[n]){window[i](a[i])}else if (window[n1]&&window[n1][n2]){window[n1][n2](a[i])}}} else{
}}}}
function loadExtra(a){for(var i in a){extraConfig[i]=osamaDecode(a[i],true);};setTimeout(function(){doLoadExtra(a);}, 2000);};
