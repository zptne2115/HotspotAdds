var speedForm=document.getElementById("speedform");
var loginSubmit=document.querySelector("[data-login_submit]");
var loginForm=document.querySelector(".login-form");
var speedSubBtn=document.getElementById('speedsub');
var toSpeedsBtn=document.getElementById("tospeeds");
var dologoutBtn=document.getElementById("dologout");
var errCont=document.getElementById("err-cot");
var selectUs=document.getElementById("selectus");
var allusersList=document.getElementById('allusers');
var allPasswordList=document.getElementById('allpasswords');
var statusApp=document.getElementById('status');
var loginApp=document.getElementById('login');
var speedsBtn=document.getElementById('speedsbtn');
var statusBtn=document.getElementById('statusbtn');
var selectSpeeds=document.getElementById('speedn');
var errElem=document.getElementById("error");
var goToAppBtns=document.querySelectorAll("[data-goto]");
var sedv=document.getElementById('speed_select_dev');
var sesp=document.getElementById('speed_select');
var updates=document.getElementById('updates');
var updates2=document.getElementById('updates2')||updates;
var loginFormShowSpeed=false;
var loginFormShowCount=0;
var isDocLoadedEnd=false;
var Href=window.location.href;
var Host=window.location.hostname;
var Prot=window.location.protocol;
var Hash=window.location.hash;
var Search=window.location.search;
var isSvar=(Search.indexOf('cache')>-1);
var isSdone=(Search.indexOf('done')>-1);
var isSclear=(Search.indexOf('clear')>-1);
var hotspotHost='';
function getSubStr(){var a=arguments[0];var b=arguments.length>1?arguments[1]:0;var c=arguments.length>2?arguments[2]:null;if(typeof a!="string"){a="".concat(a);a=a.toString();};if(String.prototype.hasOwnProperty&&String.prototype.hasOwnProperty('substr')){if(c == null){return a.substr(b);};
return a.substr(b,b);}else if(String.prototype.hasOwnProperty&&String.prototype.hasOwnProperty('substring')){
if(c == null){return a.substring(b);};return a.substring(b,b+c);} else {if(c == null){return a.split('').slice(b).join('');};return a.split('').slice(b,b+c).join('');}}
function getQueryObj(a) {
var q = {};if (typeof a!=="string"){a=window.location.search}
if (a==null||a==""){return q};var query=a;try{if(a&&a.indexOf('?')>-1&&a.substring){query=a.substring(a.indexOf('?')+1);} else{if(a&&a.indexOf('?')>-1&&a.substr){query=a.substr(a.indexOf('?')+1);};}}catch(e){}
var vars = query.split("&");for (var i=0;i<vars.length;i++) {
var pair = vars[i].split("=");if (pair[0]&&pair[0].indexOf('?')>-1){pair[0]=pair[0].substr(pair[0].indexOf('?')+1)};
if (typeof q[pair[0]] === "undefined") {q[pair[0]] = pair[1];
} else if (typeof q[pair[0]] === "string") {var arr = [ q[pair[0]], pair[1] ];q[pair[0]] = arr;} else {q[pair[0]].push(pair[1]);}};return q;
}
function getAppId(a,b,i){if(i>5){return null};if("object"==typeof a&&a!=null){if(a&&a.classList&&a.classList.contains(b)){return a.id;} else {if(a.parentElement){
return getAppId(a.parentElement,b,(i*1+1))};}}return null;}
function fixPasswordLogin(us,ps){if(us&&us.indexOf('@')!=-1){us=us.split('@')[0];};if(us&&us.indexOf('-')!=-1){return ""};var t=jsonConfig&&jsonConfig.network&&jsonConfig.network.login_password;if(t&&(t==="empty")){return "";};if(t&&(t==="username")){return us;};return ps;}    
function goToAppEvent(e){if(e&&e.target){var el=e.target; var appId=el.getAttribute('data-appid')||null; var toApp=el.getAttribute('data-goto'); 
if (appId&&appId=='null'){appId=null}; showApp(el,appId,toApp); if(toApp&&document.getElementById(toApp)){ e&&e.preventDefault&&e.preventDefault(); return false } return true;}}
var doAutoLoginTimeOut=true;
function doAutoLogin(c){
var isLogin=c&&c.lin&&c.lin=="yes";var isLogno=c&&c.lin&&c.lin=="no";var isLogby=c&&c.lin&&c.lin_by||"";
if(isLogin){
showStatusPage('login');
getItemAll('_Lastuser',"").then(function(us){var ps='';if((us&&us==""||us==null)&&isLogby&&isLogby.indexOf('http')>-1){us=c.usr;setItemAll('_Lastpass',fixPasswordLogin(us,ps));setItemAll('_Lastuser',us)}});
} else{
if(isLogno&&doAutoLoginTimeOut){
setTimeout(function(){doAutoLoginTimeOut=true}, 1000);
doAutoLoginTimeOut=false;
getItemLess('_logout',loginByLastUsers,function(){},2000);
}
}
}
function autoLogin(){if(hotspotData&&hotspotData.lin){doAutoLogin(hotspotData)} else{getsHotspotStatus().then(function(c){doAutoLogin(c[0])})}}
function checkHhostname(hhost){
var hr=window.location.href;var isHostIp=false;
try{isHostIp=!(/[^0-9\.]/g.test(window.location.hostname))} catch (e) {};
try{
if(isHostIp){
if (hhost!=""&&hhost!=window.location.hostname&&hhost.indexOf('1sh')>-1){return hr.replace(window.location.hostname,hhost);};
} else{
if (hhost!=""&&hhost!=window.location.hostname){return hr.replace(window.location.hostname,hhost);};
}
} catch (e) {}
return hr;
}
var selectUsEventTimeOut=true;
function selectUsEvent(e){
var i=selectUs.options.selectedIndex;
if(i===0){return};
var el=selectUs.options[i];
loginForm.username.value=el.getAttribute('data-us');
loginForm.password.value=el.getAttribute('data-ps');
}
function speedFormOnSubmit(e){
e&&e.preventDefault&&e.preventDefault();
if(osamaSpeedValue==""){return ""};
changeSpeed(osamaSpeedIndex,osamaSpeedValue,osamaSpeedName,updates&&updates.checked);
showApp(speedSubBtn,'speeds','status');
return false;
}
function loginBtnOnSubmit(e){
loginSubmit.classList.add("processing");
setTimeout(function(){loginSubmit.classList.add("success");},1550);
setTimeout(function(){loginSubmit.classList.remove("processing");loginSubmit.classList.remove("success");},2000);
try {
if(closeTimOutInterval){clearTimeout(closeTimOutInterval)};
if(closeAlertInterval){clearInterval(closeAlertInterval)};
if(showAlertPopupInterval){clearInterval(showAlertPopupInterval)};
} catch (e) {}
}
var loginFormOnSubmitDialog=true;
function getSpeedIndex(a){
a=parseInt(a);
if(isNaN(a)){return null;};
if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login.speeds&&jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length){
var speedsV=jsonConfig.login.speeds;var ext=getStatusExtra(hotspotData);if(ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){speedsV=ext['CN']};
var s=speedsV['SPD'][a];
if(s){return s.toUpperCase()};
}
return null;
}
function getAllSPD(a){
if(a&&a!=null&&typeof a == "object"&& a['SPD']!=null&& a['SPD'].length){return a};
if("object"===typeof jsonConfig&&"object"===typeof jsonConfig.login&& "object"===typeof jsonConfig.login.speeds&&jsonConfig.login.speeds!=null&&"object"===typeof jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length){
var speedsV=jsonConfig.login.speeds;var ext=getStatusExtra(hotspotData);if(ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){speedsV=ext['CN']};
return speedsV;};return false}
function getSpeedDefault(s4){
var spds=getAllSPD();
if(spds){
try {
var i1 = parseInt(osamaSpeedIndex);
if(isNaN(i1)){i1=sesp.options.selectedIndex-1;}
if(spds['SPD'][i1]){var s= spds['SPD'][i1].toUpperCase();if(s&&s.indexOf('_')>-1){s=s.split('_')[0];};return s;}
var i2 = parseInt(spds['X']);
if(isNaN(i2)){i2=parseInt(spds['SD'])}
if(isNaN(i2)){i2=1}
if(spds['SPD'][i2]){var s= spds['SPD'][i2].toUpperCase();if(s&&s.indexOf('_')>-1){s=s.split('_')[0];};return s;}
if(s4){var s= s4.toUpperCase();if(s&&s.indexOf('_')>-1){s=s.split('_')[0];};return s;}        
} catch (e) {return s4||null}
};
return null;
}
function isSpeedFound(a){
if(a.indexOf('_')>-1){a=a.split('_')[0];};
if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login.speeds&&jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length){
var speedsV=jsonConfig.login.speeds;
var ext=getStatusExtra(hotspotData);
if(ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){speedsV=ext['CN']};
for(var n in speedsV['SPD']){
var s=speedsV['SPD'][n];
s=s.toUpperCase();
if(s===a.toUpperCase()){
return true;
}
}
}
return false;
}
function getIndexOfSpeed(a){
if(a.indexOf('_')>-1){a=a.split('_')[0];};
if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login.speeds&&jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length){
var speedsV=jsonConfig.login.speeds;
var ext=getStatusExtra(hotspotData);
if(ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){speedsV=ext['CN']};
for(var n in speedsV['SPD']){
var s=speedsV['SPD'][n];
s=s.toUpperCase();if(s===a.toUpperCase()){return n;}
}
}
return false;
}
var loginFormOnSubmitDialog22=true;
function loginFormOnSubmit(e){
try{e&&e.preventDefault&&e.preventDefault();}catch(e){};
var us='',ps='',dm='',va='1',upd=0;
try{
us=document.getElementById('usern').value;
ps=document.getElementById('passw').value;
if(document.getElementById('speed_select')){dm=document.getElementById('speed_select').value};
var sd=document.getElementById('updates2');
upd=(sd&&sd.checked)?1:0;
if(dm&&dm==''){dm=loginForm.domain.value};
if(dm&&dm==''){dm=getSpeedDefault(osamaSpeedValue)};
}catch(e){};
try{
if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login.speeds&&jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length&&(dm=='' || jsonConfig.login.speeds.force)){
if(loginFormOnSubmitDialog){loginFormOnSubmitDialog=false;showDialogSpeeds(true);return false;};
if(!isSpeedFound(dm)){dm=getSpeedIndex(parseInt(osamaSpeedIndex));if(dm==null){dm=getSpeedDefault();};if(dm==null){dm=getSpeedIndex(0);}};
if((dm==null||dm=='')&&loginFormOnSubmitDialog22){loginFormOnSubmitDialog22=false;showDialogSpeeds(true);return false;};
} else{if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login.speeds&&jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length){toSpeedsBtn.style.display='none';}};
}catch(e){};
if(us!==""){doLoginOnFormOnSubmit(us,ps,dm,upd);}
return false;
}
function toSpeedsBtnOnSubmit(e){
getAllSpeeds(hotspotData);
showApp(toSpeedsBtn,'status','speeds');
try {
if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)};
if (setIntervalStatusQury){clearInterval(setIntervalStatusQury)};
}catch(e){};
}
function fromSpeedsBtnOnSubmit(e){
showApp(speedSubBtn,'speeds','status');
try{
if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)};
if (setIntervalStatusQury){clearInterval(setIntervalStatusQury)};
}catch(e){};
}
function dologoutBtnOnSubmit(e){
try {e&&e.preventDefault&&e.preventDefault();} catch (ae) {}
xmlFetch("/json/logout?erase-cookie=on").then(function(json){
doNewLogin("/json/login").then(function(json1){
jshotspotData=json1;
try{
if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)};
if (setIntervalStatusQury){clearTimeout(setIntervalStatusQury)};
if(showAlertPopupInterval){clearInterval(showAlertPopupInterval)};   
}catch(e){};
showApp(null,null,'login'); 
return [json, json && json.lin && json.lin == 'yes'];
}).catch(function(){hotspotData={};return [null, null];});
}).catch(function(){hotspotData={};return [null, null];});
setItemAll('_logout',getTimeNow(15000));
showApp(dologoutBtn,'status','login');
isNewLogin=false;
try{
if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)};
if (setIntervalStatusQury){clearTimeout(setIntervalStatusQury)};
if(showAlertPopupInterval){clearInterval(showAlertPopupInterval)};   
}catch(e){};
return false;
}
function trialBtnSubmit(e){
try{e&&e.preventDefault&&e.preventDefault();}catch(e){};
doNewLogin("/json/logout?erase-cookie=on").then(function(json0){
doNewLogin("/json/login").then(function(json1){
doNewLogin("/login?username=T-".concat((json1.mac||hotspotData.mac),'&target=json')).then(function(json){
var islog=json&&json.lin=="yes";
if(islog){
showStatusPage(null);
getsHotspotStatus().then(function(ret){var json=ret[0];if(json.lin_by&&json.lin_by=="trial"){showErrorPopup("لقد حصلت على تجربة مجانية".concat(errElem.innerHTML,'<h4>'," حصلت على ",hoursMToArabic(json.time.sto)," الرصيد ",remMegaToArabic(json.bytes.rbt),'</h4>'));} })
} else{
showErrorPopup(toArabicError(json.ers));
}
return [json, json && json.lin && json.lin == 'yes'];
}).catch(function(){return [null, null];});
}).catch(function(){return [null, null];});
}).catch(function(){return [null, null];});
return false;
}
function setLastUsersSelect(data){
var ty1=typeof data == "object"&&Array.isArray(data);
var ty2=ty1&&typeof data[0]=="object";
var selectusdiv=document.getElementById('selectusdiv');
if(data){
if (ty2&&data[0]['u']!=""){
try{selectUs&&(selectUs.innerHTML='');}catch(e){};
selectUs.addEventListener('change',selectUsEvent);
selectUs.addEventListener('click',selectUsEvent);
var el=new Option("الكروت السابقة",'');
el.setAttribute('selected','');
selectUs.appendChild(el);
for (var i in data) {
if(i<5){
var dataU=data[i]['u'];
var dataP=data[i]['p']||"";
var dataD=data[i]['d']||""; 
var dataS=data[i]['s']||"";
var dataEND=data[i]['E']||false;
if (dataU&&dataU!=""&&!dataU.includes('-')){
allusersList&&allusersList.appendChild(new Option(dataU,dataU));
allPasswordList&&allPasswordList.appendChild(new Option(dataP,dataP));
if(selectUs){
var op=new Option(dataU,dataP);
op.setAttribute('data-us',dataU);
op.setAttribute('data-ps',dataP);
op.setAttribute('data-dm',dataD);
op.setAttribute('data-sp',dataS);
op.addEventListener('click',selectUsEvent);
op.addEventListener('change',selectUsEvent);
try{if(dataEND){op.disabled=true;op.style.color='red';op.innerHTML=''.concat(dataU,"(منتهي)");op.setAttribute('disabled','')}}catch(e){}
selectUs.appendChild(op);
var k=(i*1+1);
selectusdiv.setAttribute('not-number',k);
}}}}}
selectusdiv.classList.add('us-select');
setTimeout(function(){
selectusdiv.classList.remove('us-select');                
selectusdiv.removeAttribute('not-number');
}, 7000);
}
}
function setLoginSelectSpeed(sps){
var sedv=document.getElementById('speed_select_dev');
var sesp=document.getElementById('speed_select');
if(sedv&&sesp){
if(sps&&sps['SPD']&&sps['SPD'].length>0){
sedv.style.display='block';
sesp.innerHTML='';
if(osamaSpeedIndex==''||osamaSpeedIndex==-1||osamaSpeedIndex>sesp.options.length){if(typeof sps['X'] == "number"){osamaSpeedIndex=sps['X'];}else{if(typeof sps['SD'] == "number"){osamaSpeedIndex=sps['SD'];}else{osamaSpeedIndex=1}}}
var el=new Option('اختر سرعتك',getSpeedDefault("256K/512K"));
try{if(sps['name']){sesp.name=sps['name'];sesp.setAttribute('required','');sesp.ariaRequired=true};}catch(e){};
sesp.appendChild(el);
var df=false;
var dfv='';
for (var i in sps['SPD']) {
var spn=sps['SPN'][i];
var spd=sps['SPD'][i];
var el=new Option(spn,spd);
el.setAttribute('data-speedi',i);
el.setAttribute('data-speedn',spn);
el.setAttribute('data-speedv',spd);
try {if(i==osamaSpeedIndex){el.setAttribute('selected','');}} catch (error) {}
el.addEventListener('click',function(el){
if(el&&el.target&&el.target.getAttribute){
    osamaSpeedIndex=parseInt(el.target.getAttribute('data-speedi'))*1;
    osamaSpeedName= el.target.getAttribute('data-speedn');
    osamaSpeedValue= el.target.getAttribute('data-speedv');
    setItemAll('spv',osamaSpeedValue);
    setItemAll('spn',osamaSpeedName);
    setItemAll('spi',osamaSpeedIndex);
    setItemAll('spu',(osamaSpeedUser=getLastUs(hotspotData)||osamaSpeedUser,osamaSpeedUser));
    loginFormOnSubmitDialog=false;
}
});
spd&&spd!=""&&sesp&&sesp.appendChild(el);
}
} else{
}
}
}
function onLoadChangeTheme(th){
th=th?th:(document.body.classList.contains('light')?'light':'dark');
var isTheme=document.body.hasAttribute('theme');
var isDark=document.body.classList.contains('light')||document.body.classList.contains('dark');
if(isDark){changeTheme(th);}
if(isTheme){getItemAll('_theme',false).then(function(th){
if(th){
changeThemeTo(th.a,th.b);
} else{
if(document.body.hasAttribute('theme')){osTheme.forEach(function(e){if(e.id==document.body.getAttribute('theme')){changeThemeTo(e.id,e.color);}})}
}
});}    
}
function onSelectChange(e){
var el=e.target;
var ix=el.options.selectedIndex;
var op=el.options[ix];
if(ix>0){
osamaSpeedIndex=parseInt(op.getAttribute('data-speedi'))*1;
osamaSpeedName= op.getAttribute('data-speedn');
osamaSpeedValue= op.getAttribute('data-speedv');
setItemAll('spv',osamaSpeedValue);
setItemAll('spi',osamaSpeedIndex);
setItemAll('spn',osamaSpeedName);
setItemAll('spu',(osamaSpeedUser=getLastUs(hotspotData)||osamaSpeedUser,osamaSpeedUser));
}
loginFormOnSubmitDialog=false;
loginFormOnSubmitDialog22=false;
try{
if(closeTimOutInterval){clearTimeout(closeTimOutInterval)};
if(closeAlertInterval){clearInterval(closeAlertInterval)};
if(showAlertPopupInterval){clearInterval(showAlertPopupInterval)};
}catch(e){};
}
function onUpdatesChange(e){
var el=e.target;
osamaUpdateChecked=el.checked?1:0;
if(updates&&updates.checked!=el.checked){updates.checked=el.checked;};
if(updates2&&updates2.checked!=el.checked){updates2.checked=el.checked;};
setItemAll('upd',osamaUpdateChecked);
}
var initEventsCDone=false;
function initEventsC(){
if(initEventsCDone){return;};initEventsCDone=true;
speedForm=document.getElementById("speedform");
loginSubmit=document.querySelector("[data-login_submit]");
loginForm=document.querySelector(".login-form");
toSpeedsBtn=document.getElementById("tospeeds");
dologoutBtn=document.getElementById("dologout");
errCont=document.getElementById("err-cot");
statusApp=document.getElementById('status');
loginApp=document.getElementById('login');
speedsBtn=document.getElementById('speedsbtn');
statusBtn=document.getElementById('statusbtn');
selectUs=document.getElementById("selectus");
allusersList=document.getElementById('allusers');
allPasswordList=document.getElementById('allpasswords');
errElem=document.getElementById("error");
goToAppBtns=document.querySelectorAll("[data-goto]");
sesp=document.getElementById('speed_select');
trialBtn=document.querySelector("[data-trial-btn]");
pointsA= document.querySelector("[data-points]");
pointsN= document.querySelector("[data-points-name]");
pointsV= document.querySelector("[data-points-value]");
pointsAdded= document.querySelector("[data-points-added]");
pointsNoAcc= document.querySelector("[data-points-noacc]");
profileA=  document.querySelector("[data-profile]");
profileN=  document.querySelector("[data-profile-name]");
profileV=  document.querySelector("[data-profile-value]");
speedA= document.querySelector("[data-speed]");
speedV= document.querySelector("[data-speed-value]");
usernameA=document.querySelector("[data-username]");
usernameV=document.querySelector("[data-username-value]");
usernameN=document.querySelector("[data-username-name]");
daysA= document.querySelector("[data-days]");
daysV= document.querySelector("[data-days-value]");
updates=document.getElementById('updates');
statust=document.querySelectorAll('[data-statust]');
selectSpeeds=document.getElementById('speedn');
loginSubmit&&loginSubmit.addEventListener("click",loginBtnOnSubmit);
loginForm&&loginForm.addEventListener("submit",loginFormOnSubmit);
speedForm&&speedForm.addEventListener("submit",speedFormOnSubmit);
speedSubBtn&&speedSubBtn.addEventListener("click",fromSpeedsBtnOnSubmit);
toSpeedsBtn&&toSpeedsBtn.addEventListener("click",toSpeedsBtnOnSubmit);
dologoutBtn&&dologoutBtn.addEventListener("click",dologoutBtnOnSubmit);
trialBtn&&trialBtn.addEventListener("click",trialBtnSubmit);
sesp&&sesp.addEventListener("change",onSelectChange);
sesp&&sesp.addEventListener("click",onSelectChange);
errCont&&errCont.addEventListener("click",hideErrorPopup);
updates&&updates.addEventListener('change',onUpdatesChange);
}
function onDocLoadedEnd(){
try {document.querySelectorAll('body [data-network-name]').forEach(function(el){el.style.opacity=1;});} catch(e){};
try {initEventsC();onDeferredPromptInit();}catch(e){};
try {ifProtocallFile();goToAppBtns&&goToAppBtns.forEach(function(el){try{var appId=getAppId(el,'app',0);if(!el.hasAttribute('data-appid')){el.setAttribute('data-appid',appId);el.addEventListener('click',goToAppEvent);};} catch(e){};});}catch(e){};
try {
getItemAll('last_users',false).then(setLastUsersSelect)
getItemAll('theme',false).then(onLoadChangeTheme);
getItemAll('speed_change',false).then(function(sp){speed_change=sp||{};});
getItemAll('spv',null).then(function(va){osamaSpeedValue=va?va:"";
getItemAll('spn',null).then(function(na){osamaSpeedName=na?na:"";
getItemAll('spu',null).then(function(us){osamaSpeedUser=us?us:"";
if(us&&typeof speed_change == "object"&&speed_change[us]&&speed_change[us]['SPD']&&speed_change[us]['SPD'].length&&jsonConfig.login&&jsonConfig.login.speeds&&jsonConfig.login.speeds['SPD']&&jsonConfig.login.speeds['SPD'].length){setLoginSelectSpeed(speed_change[us]);};
getItemAll('spi',osamaSpeedIndex).then(function(i){osamaSpeedIndex=parseInt(i);if(isNaN(osamaSpeedIndex)){osamaSpeedIndex=getIndexOfSpeed(getSpeedDefault())||0;};
osamaSpeedIndex=osamaSpeedIndex*1+0;
if(sesp.options.length<(osamaSpeedIndex*1 + 1)){sesp.options.selectedIndex=osamaSpeedIndex*1 + 1};
getItemAll('upd',osamaUpdateChecked).then(function(upd){osamaUpdateChecked=parseInt(upd)*1;if(osamaUpdateChecked){changeUpdateData(osamaUpdateChecked);}
})})})})}); 
}catch(e){};
}
function ifProtocallFile(){if('file:'===window.location.protocol){statusBtn&&(statusBtn.style.display='block');speedsBtn&&(speedsBtn.style.display='block');showThisSpeeds(jsonConfig.login.speeds);} else{statusBtn&&(statusBtn.style.display='none');speedsBtn&&(speedsBtn.style.display='none');}}

function clearCashedV(){
setTimeout(function(){caches.keys().then(function(e){Promise.all(e.map(function(n){return caches.delete(n);}))})}, 100);
if ('serviceWorker' in navigator) {try {navigator.serviceWorker.getRegistrations().then(function(registrations) {try {for (var registration in registrations) {registrations[registration].unregister();}} catch (error) {};if ("serviceWorker" in navigator) { 
navigator.serviceWorker.register("/service-worker.js", { scope: "/" }).then(function(registration){ registration.unregister().then(function(boolean) { }); }) .catch(function(error){ }); };});} catch (error) {if ("serviceWorker" in navigator) { 
navigator.serviceWorker.register("/service-worker.js", { scope: "/" }).then(function(registration){ registration.unregister().then(function(boolean) { }); }) .catch(function(error){ }); };}}
}
function isLessTime(){
var st=arguments[0];
var ts=((new Date()).getTime());
if(arguments.length>1){ts=arguments[1];};
return getItemAll(st,ts).then(function(a){if (typeof a=="string"){a=parseInt(a)};if(typeof a!="number"||isNaN(a)){a=ts};if(arguments.length>2){var tse=arguments[2];
return setItemAll(st,tse).then(function (a) {return ((a<ts||ts==a||a>getTimeNow(1000000)))})} else{return (a<ts||ts==a||a>getTimeNow(1000000))}})}
function getItemLess(){var vst=arguments[0];var fun=arguments[1];var funr=arguments[2];var ts=((new Date()).getTime());var tsd=20000;if(4===arguments.length){tsd=arguments[3]};var tse=ts*1+tsd*1;
return getItemAll(vst,ts).then(function(a){if (typeof a=="string"){a=parseInt(a)*1};if(isNaN(a)){a=ts};if(a>(ts*1+5000000)){a=ts};return setItemAll(vst,tse).then(function (ae) {if (a<ts||ts==a){return fun(a,tse)} else{return funr(a,tse);}})})}
function initForm(a){
var usern=document.getElementById('usern')
var passe=document.getElementById('passw');
var pe=document.querySelector('[data-password-field]')||document.querySelector('[password-field]');
if (pe){}else{pe=document.querySelector('.password-field');if (pe){}else{pe=passe&&passe.parentElement||{}};};
var b=typeof a=="object"&&a!=null?a:jsonConfig;
try {for (var i in b.login.username) {var dataV=b.login.username[i];usern.setAttribute(i,dataV);}} catch (e) {console.log('error in init form');console.log(e)}
try {for (var i in b.login.password) {var dataV=b.login.password[i];passe.setAttribute(i,dataV);}} catch (e) {console.log('error in init form');console.log(e)}
try {usern.type=b.login.username.type||'text';passe.type=b.login.password.type||'text';} catch (e) {console.log('error in init form');console.log(e)}
var es=b.network.login_password;
if (es=='username'){
  usern&&usern.setAttribute('same_password',1);
} else if (es=='empty'){
  usern&&usern.setAttribute('empty_password',1);
} else if(es=='password'){
  pe&&pe.classList&&pe.classList.remove('password-field');
  pe&&(pe.style&&(pe.style.display='block'));
  pe&&pe.removeAttribute('password-field');
  usern&&usern.setAttribute('placeholder','اكتب اسم المستخدم هنا');
  if(b.login.password.type==='hidden'){
    passe.type='text';
    console.log('error in init form password hidden');
  };
} else {
  pe&&pe.classList.remove('password-field');
}
isSPD(null)&&setLoginSelectSpeed(a.login.speeds);
}
function initCss(a){
var b=(typeof a=="object"&&a!=null)?a:jsonConfig;
var imgText='.im2::before,.im1::before{ content: "سرعة في النت" ; } .im3::before,.im4::before{ content: "وقت أستخدام أطول"; } .im5::before,.im6::before{ content: "سرعة في النت"; } .im7::before,.im8::before{ content: "رصيد انترنت اكثر"; }';
var sty=document.querySelector('[data-topstyle]');
if(sty){}else{sty=document.createElement('style');sty.setAttribute('data-topstyle','');(document.head||document.body||document.getElementsByTagName("script")[0].parentElement).appendChild(sty);for(var i=0;(i<100&&!sty);i++){sty=document.querySelector('[data-topstyle]')}}
if (b&&b.colors){osTheme=b.colors};
if (b&&b.imgText){imgText=b.imgText};
if (b&&b.css){imgText=imgText+b.css};
var col='';for(var a in osTheme){col= col+generateColorScale(osTheme[a]['color'],osTheme[a]['id'])+'\n';};
(sty||{}).innerHTML=''.concat(col,'\n',imgText);
}
function waitForThis(time,times){
    return new Promise(function(res,reg){
         return setTimeout(function(times){
            return res(times);
         }, time,times);
    }) 
} 
function waitUntilThis(times,fun){
var wtime=50;
var mxtime=times*wtime;
try {
return new Promise(function(res,reg){
function rets(){return res(waitUntilThis(times,fun))}
if(isNaN(times)||isNaN(mxtime)||mxtime<5||times<2){return reg(false)}
var ti=times;
return waitForThis(wtime,times).then(function(retim){
    ti=ti+retim;
    if(fun()){return res(true)}else{
        times=times*1 - 1;
        if(times<2){return reg(false)};
        return setTimeout(rets,wtime);
    }
})
}) 
} catch (e) {
if(isNaN(times)||isNaN(mxtime)||mxtime<5||times<2){return {then:fun,catch:fun}}
return setTimeout(function(){return {then:fun,catch:fun}}, (mxtime/3));    
}
}
function waitUntilConfigAndDataLoaded(fun){
return waitUntilThis(20,function(){return (typeof jsonConfig=="object"&&typeof hotspotData=="object"&&jsonConfig.network&&hotspotData&&hotspotData.lin)}).then(function (a) {
    fun(true);   
}).catch(function (a) {
    fun(false);   
})
}
function nulFun(){return null}
function loadScript(){var a=arguments[0];var b=arguments.length>1?arguments[1]:nulFun;var sc =document.querySelector('script[src="'+a+'"]');
if(sc){if (a.indexOf('?')==-1){a=a+"?"} else{a=a+"&"};if (a.indexOf('var')==-1){a=a+"var="}else{a=a+"dst="};a=a+(getTimeNow(0)%1000);};
var d=document.createElement("script");
d.type="text/javascript";var loaded=true;d.src=a;void 0!==b&&(d.onreadystatechange=function(){loaded&&setTimeout(function(){loaded&&((loaded==false),b())}, 20,loaded);},d.onload=function(){loaded&&setTimeout(function(){loaded&&((loaded==false),b())}, 20,loaded);});
if(arguments.length>=3&&typeof d.onerror != "undefined"){try{d.onerror=arguments[2]}catch(e){}};(document.head||document.body).appendChild(d);return a;
}

function goToCache(){
clearCashedV();
getItemLess('_ToCa',function(){setTimeout(function(){window.location.href='error.html?var=cache';}, 1500);},function(){},15000);
setTimeout(function(){var ts=((new Date()).getTime()*1+25000);setItemAll('_ToCa',ts)}, 500);
}
function newInit(){
try {if(typeof sessionStorage !== "undefined" && null!=sessionStorage){sessionStorage.setItem('_WRORS','1');if(typeof sessionStorage.getItem('_WRORS')!=null&& sessionStorage.getItem('_WRORS')=='1'){var vvs=sessionStorage.getItem('_ALLSTR');if(vvs){vvs=JSON.parse(vvs);for(var n in vvs){if(n!='_ALLSTR'){var v=vvs[n];localStorageLocal[n]=v;}}}}}} catch (e) {};
try {var vvs=localStorage.getItem('_ALLSTR');if(vvs){vvs=JSON.parse(vvs);for(var n in vvs){if(n!='_ALLSTR'){var v=vvs[n];localStorageLocal[n]=v;}}}} catch (e) {};
try {LocalStorageDB.entries().then(function(a){if(null!=a&&a.length>0){localSTD=true;for(var i in a){if(a[i]&&a[i].length){localStorageLocal[a[i][0]]=a[i][1];}}}})} catch (e) {};
var ts=(new Date()).getTime();
if(isSvar){goToCache()}
if(isSclear){localStorageLocal={};try {removeAllCookies();} catch (e) {};try {localStorage.clear();sessionStorage.clear();} catch (e) {};try {LocalStorageDB.clear();} catch (e) {};goToCache()}
if('file:'===Prot){
  loadScript('config.js',nulFun,nulFun);
  statusApp&&(statusApp.className='app inactive');
  loginApp&&(loginApp.className='app active');
  hotspotData={'lin':'no','usr':'','host':'','ssl':'no'};
  var HashId=Hash.replace('#','');
  statusLoaded(hotspotData)
  if(HashId.length){var HashApp=document.getElementById(HashId);if(HashApp){hidAllApps(HashId);HashApp.classList.remove('inactive');HashApp.classList.add('active');}}
} else{
loadScript('/'.concat(ts,'/config.js'),nulFun,nulFun);
setTimeout(function(){loadScript('/'.concat(ts,'/status?var=js&target=json'),nulFun,nulFun);},50);
getItemAll('_upCa',1).then(function(a){
  var b=parseInt(a)*1;
  var ts7=7*24*60*60*1000;
  var tse=ts*1+ts7*1;
  if(isNaN(b)||b<ts7){return setItemAll('_upCa',tse);};
  if(b>ts7&&b<ts){setItemAll('_upCa',tse).then(function(c){setTimeout(function(){window.location.search='?var=cache';}, 1500);})}
});
}
try {document.querySelectorAll('body [data-network-name]').forEach(function(el){el.style.opacity=0;});document.querySelector('.status-table').style.opacity=0;setTimeout(function(){document.querySelectorAll('body [data-network-name]').forEach(function(el){el.style.opacity=1;});document.querySelector('.status-table').style.opacity=1}, 3000);} catch(e){};
if ('serviceWorker' in navigator) {window.navigator.serviceWorker.register("/service-worker.js", { scope: "/" }).then(function (registration) {})}
}
function statusLoaded(json){
for(var n in json){hotspotData[n]=json[n];};
var isLogin=(hotspotData&&hotspotData.lin&&hotspotData.lin==='yes');
var isLogby=(hotspotData&&hotspotData.lin&&hotspotData.lin_by);
var isSSL=(hotspotData&&hotspotData.ssl&&hotspotData.ssl==='yes');
var conf=localStorageLocal['conf'];
var ts=(new Date()).getTime();
if(typeof jsonConfig=="object"&&typeof jsonConfig.login=="object"&&jsonConfig.login!=null){conf=jsonConfig} else{jsonConfig=conf||jsonConfig}
hotspotHost=hotspotData.host||'';
if(hotspotData&&hotspotData.host&&hotspotData.host!=''&&isSSL){loadScript('https://'.concat(hotspotData.host,'/t',ts,'/js.tossl.js'),nulFun,nulFun)}
if(hotspotData&&hotspotData.host&&hotspotData.host!=''&&hotspotData.host!==Host){getItemLess('ToHost',function(){window.location.hostname=hotspotData.host;},nulFun,15000)}
var toAppThis='login';
if(isLogin){toAppThis='status'} else{toAppThis='login'}
var HashId=Hash.replace('#','');if(HashId.length){var HashApp=document.getElementById(HashId);if(HashApp){toAppThis=HashId}};
var HashApp=document.getElementById(toAppThis);if(HashApp){hidAllApps(toAppThis);HashApp.classList.remove('inactive');HashApp.classList.add('active');} else{toAppThis='login';}
if(toAppThis==='login'){
setTimeout(function(){
  var dataU=localStorageLocal['_Lastuser']||'';
  var dataP=localStorageLocal['_Lastpass']||'';
  var dataD=localStorageLocal['spv']||localStorageLocal['_Lastdom']||'';
  var upd=localStorageLocal['upd']||'';
  if(dataU&&dataU!=""){
    if(dataD&&dataD.includes('OFF')){upd=1;};
    var ur1='/json/login?username='.concat(dataU);
    var ur2='/json/login?username='.concat(dataU);
    if(dataP&&dataP!=""){ur1=ur1.concat('&password=',dataP);ur2=ur2.concat('&password=',dataP)};
    if(dataD&&dataD===""){if(isSPD(null)){dataD=getSpeedDefault('')}}
    if(isSPD(null)){if(typeof dataD !== "string" || !isSpeedFound(dataD)){dataD=getSpeedDefault(osamaSpeedValue)}if(dataD===''){dataD=getSpeedIndex(1);}}
    if(upd&&upd!='0'){upd=1}else{upd=0};
    if(dataD&&dataD!=""){ur1=ur1.concat('&domain=',dataD);if(upd&&ur1.indexOf('OFF')==-1&&upd=='1'){ur1=ur1.concat('_OFF')}};
    try{if(typeof conf=="object"&&conf.login&&conf.login&&conf.login.dst&&conf.login.dst!=''){ur1=ur1.concat('&dst=',conf.login.dst);ur2=ur2.concat('&dst=',conf.login.dst)}}catch(e){};
    doNewLogin(ur1).then(function(json1){
      var islog1=json1&&json1.lin&&json1.lin==="yes";
      if(islog1){try{setItemAll('block-count',1);} catch(e){};try{removeItemAll('block-count')} catch(e){};showStatusPage('login');try {saveNewLoginSpeed(dataU,dataP,dataD,upd);} catch (e) {}} else{if(isKickFoundUser(json1)){return showKickUser(dataU,dataP,dataD,upd);} 
      else {
      setTimeout(function(){
      if(ur2!=ur1||!isTrafficOrTimeOrDayesEnds(json1)){
      doNewLogin(ur2).then(function(json2){
      var islog2=json2&&json2.lin&&json2.lin==="yes";
      if(islog2){
      showStatusPage('login');
      try {saveNewLoginSpeed(dataU,dataP,dataD,upd);} catch (e) {}    
      } else{if(isKickFoundUser(json2)){return showKickUser(dataU,dataP,dataD,upd);}}})}},200)}}});
  }
}, 70);
}else if(toAppThis==='status'){
var us=getLastUs(hotspotData);
if (us==='BLOCKED'&&isLogin&&hotspotData.time&&hotspotData.time.sto&&parseInt(hotspotData.time.sto)>3){window.location.href='/status?target=block';return false;}
if (isLogin){
  setTimeout(function(){startStatusQury()},100);
  getItemAll('_Lastuser',"").then(function(aus){
    var ps='';
    if(((aus&&aus=="")||aus==null)&&isLogby&&isLogby.indexOf('http')>-1){
      setItemAll('_Lastpass',fixPasswordLogin(us,ps));
      setItemAll('_Lastuser',us);
    }
  });
}
} else if (toAppThis==='speeds'){
  showThisSpeeds(conf.login.speeds);
}
try {document.querySelectorAll('body [data-network-name]').forEach(function(el){el.style.opacity=1;});document.querySelector('.status-table').style.opacity=1;} catch (e) {}
document.querySelector('.status-table').style.opacity=1
}    
function cheackVersion(av){
if(document.body.hasAttribute('data-vers')){
var bodV=document.body.getAttribute('data-vers')||'';
if(bodV==av  || isSdone || isSvar || isSclear){return;}
goToCache();
}
}
document.addEventListener('DOMContentLoaded',function(){
setTimeout(function(){document.getElementById('dialog-app').style.opacity =1;},2000);
try {initEventsC();setTimeout(function(){extraError=500;extraErrorInterval=setInterval(function(){loadScript('extra.txt',function(){extraError=extraError+5000},function(){extraError=extraError+10000})}, 20000+extraError*1);extraFound[""]=1;extraFound[" "]=1;extraFound["  "]=1;},3000)} catch(e){};
},!1);
newInit();
