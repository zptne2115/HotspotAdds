var salefniStart=false;
var last_users_Ends=[];
function cheackSolfah(a,k){
return new Promise(function(resolve, reject){
if(a){if(typeof a=="object"&&a!=null&&a.length>0){
var ur=a[0];
a=a.slice(1);
doLoginReq(ur).then(function(json){
    var islog=json&&json.lin&&json.lin==="yes";
    if(islog){return resolve([k,'لديك رصيد بالفعل في الكرت'+'<p>'+json.usr])};
    k=k+1;
    var us=json&&json.lin&&json.usr
    var ert=(json||{}).ert||"";
    if(ert&&(ert==='uptime-limit' || ert==='traffic-limit' || isTrafficEnds(json) || isTimeEnds(json) || isDayesEnds(json))){
        if(us&&us!=""){
            for(var x in last_users){
                if(last_users[x]&&last_users[x]['u']==us){
                    last_users_Ends.push(us);
                }
            }
        }
    }
    setTimeout(function(){
        cheackSolfah(a,k).then(resolve).catch(function(err){
            resolve([k,false]);
        })
    }, 100);
})
}else{return resolve([k,false])}}else{return resolve([k,false])}
})
}
function salefni(){
errElem.innerHTML='يرجى الانتظار ..';
showLoadingError();if(salefniStart){return salefniStart};
salefniStart=true;setTimeout(function(){salefniStart=false;}, 7000);
var urls=[];var urlsEnd=[];var urlsDone=[];var k=0;
var kSolfah=jsonConfig.apps.kadamat['SOLFAH']||3;
last_users_Ends=[];
getsHotspotStatus().then(function(data){
    if(data&&data[0]){
        hotspotData=data[0];
    }
getItemAll('last_users',[]).then(function(data){
    for(var i in data){
        last_users=data;
        var isEnd =false,isDone=false;
        if (typeof data[i]['E'] != "undefined" && data[i]['E']){isEnd=true};
        if (typeof data[i]['E'] == "undefined"||void 0 == data[i]['E']){isEnd=false};
        if (typeof data[i]['S'] == "undefined"||void 0 == data[i]['S']){isDone=false} else{isDone=true};
        if (data[i]&&data[i]['u']&&data[i]['u']!=''){
            var ur='/json/login?username='+data[i]['u'];
            if(data[i]['p']&&data[i]['p']!=''){ur=ur+'&password='+data[i]['p']};
            if(data[i]['d']&&data[i]['d']!=''&&data[i]['r']){ur=ur+'&domain='+data[i]['d']};
            if(isDone){
                urlsDone.push('/json/login?username='+data[i]['u']+'!KADAMAT');
            } else{
                if(isEnd){
                    urlsEnd.push(ur);
                    k=k+1;
                } else{                   
                    urls.push(ur);
                    k=k+1;
                }
            }
        }
    };
    var isLogin=hotspotData['lin']&&hotspotData['lin']=='yes';
    if(isLogin){showErrorPopup('انت مسجل دخولك بالفعل');return showStatusPage('kadamat')};
    var mac=hotspotData['mac'];
    var us='S-'+mac;
    doLoginReq('/json/login?username='+us).then(function(json){
        var islog=json&&json.lin&&json.lin==="yes";
        if(islog){
            return getsHotspotStatus().then(function(data){
                var json2=data[0];
                if(data&&json2.usr==us){
                    showErrorPopup('لقد حصلت على سلفة');
                    var mg1=" حصلت على "+hoursMToArabic(json2.time.sto)+" الرصيد "+remMegaToArabic(json2.bytes.rbt);
                    errElem.innerHTML+='<h4>'+mg1+'</h4>';
                    return showStatusPage('kadamat');
                } else{
                    if(k<kSolfah){
                        showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kSolfah+' كروت على الأقل خلال اخر اسبوع');
                        return showLoginPage('kadamat');
                     };
                    doLogOutReq();
                    showErrorPopup('لايمكنك استخدام الخدمة');
                }
            })
        } else{
            var ers=(json||{}).ers||"";
            var ero=(json||{}).ero||"";
            var ert=(json||{}).ert||"";
            if(ert&&(ert==='uptime-limit' || ert==='traffic-limit')){
                showErrorPopup(toArabicError(ers).replace('كرت','سلفة')+"<p>"+'   يمكنك الحصول على سلفة مرة واحدة في الاسبوع ');
                return showLoginPage(null);
            } else if(ert&&(ert==='invalid-mac')){
                showErrorPopup(' عذرا لايمكنك استخدام هذه الخدمة على هذا الخدمة ');
                return showLoginPage(null);
            } else {
                if(k<kSolfah){
                    showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kSolfah+' كروت على الأقل خلال اخر اسبوع');
                    return showLoginPage('kadamat');
                 };
                var urlsSol=[].concat(urls,urlsEnd,urlsDone);
                cheackSolfah(urlsSol.slice(0,kSolfah+2),k).then(function(a){
                    var k2=a[0];
                    if(a[1]){showErrorPopup(a[1]);return showStatusPage('kadamat');};
                    getItemAll('last_users',[]).then(function(data){
                        for(var i in data){
                            if(data[i]&&data[i]['u']&&data[i]['u']!=""){
                                for (var x in last_users_Ends){
                                    var usx=last_users_Ends[x];
                                    if(usx==data[i]['u']){
                                        data[i]['E']=true;
                                        data[i]['S']=true;
                                    };
                                };
                            };
                        };
                        setItemAll('last_users',data);
                    });
                    doLoginReq('/json/login?username=SOLFAH').then(function(json2){
                        var islog2=json2&&json2.lin&&json2.lin==="yes";
                        if(!islog2){showErrorPopup('عذرا هذة الخدمة متوقفة حاليا');return showLoginPage('kadamat');};
                        if(k2<kSolfah){showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kSolfah+' كروت على الأقل خلال اخر اسبوع');return showLoginPage('kadamat');};
                        var mac=hotspotData['mac'];
                        var us='S-'+mac;
                        doLoginReq('/json/login?username='+us).then(function(json){
                            var islog=json&&json.lin&&json.lin==="yes";
                            if(islog){
                                return getsHotspotStatus().then(function(data){
                                    var json2=data[0];
                                    if(data&&json2.usr===us){
                                        showErrorPopup('لقد حصلت على سلفة');
                                        var mg1=" حصلت على "+hoursMToArabic(json2.time.sto)+" الرصيد "+remMegaToArabic(json2.bytes.rbt);
                                        errElem.innerHTML+='<h4>'+mg1+'</h4>';
                                        return showStatusPage('kadamat');
                                    } else{
                                        doLogOutReq();
                                        showErrorPopup('لايمكنك استخدام الخدمة');
                                    }
                                })
                            } else{
                                var ers=(json||{}).ers||"";
                                var ero=(json||{}).ero||"";
                                var ert=(json||{}).ert||"";
                                if(ert&&(ert==='uptime-limit' || ert==='traffic-limit')){
                                    showErrorPopup(toArabicError(ers).replace('كرت','سلفة')+"<p>"+'   يمكنك الحصول على سلفة مرة واحدة في الاسبوع ');
                                    return showLoginPage(null);
                                } else if(ert&&(ert==='invalid-mac')){
                                    showErrorPopup(' عذرا لايمكنك استخدام هذه الخدمة على هذا الخدمة ');
                                    return showLoginPage(null);
                                } else {
                                    showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kSolfah+' كروت على الأقل خلال اخر اسبوع');return showLoginPage('kadamat');
                                }
                            }
                        })
                    })
                })
            }
        }
    })
});
});
}
function doLoginReq(ur){
return xmlFetch(ur,{}).then(function(res){
return res.json().then(function(res2){
hotspotData = res2;
return res2;
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}
function doLogOutReq(){
ur='/json/logout?erase-cookie=on';
return xmlFetch(ur,{}).then(function(res){
return res.json().then(function(res2){
hotspotData = res2;
return res2;
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
} 
function cheackCollect(a,k){
return new Promise(function(resolve, reject){
if(a){if(typeof a=="object"&&a!=null&&a.length>0){
var ur=a[0];
a=a.slice(1);
doLoginReq(ur).then(function(json){
    setTimeout(function(){
        doLogOutReq().then(function(res){
        k=k+1;
        setTimeout(function(){
            cheackCollect(a,k).then(resolve).catch(function(err){
                resolve([k,false]);
            });
        }, 100);
   })}, 100);
})
}else{return resolve([k,false])}}else{return resolve([k,false])}
})
}
var collectniStart=false;
function collectfun(){return collecti()}
function calcuPointsReq(a,k,data){
return new Promise(function(resolve, reject){
if(a){if(typeof a=="object"&&a!=null&&a.length>0){
var us=a[0];
a=a.slice(1);
var fund=false;
var ur='/json/login?username='+us+'!KADAMAT';
doLogOutReq().then(function(res){
doLoginReq(ur).then(function(json){
    if(toBoolen(json.lin)){
        k=k+1;
        data[us]['C']=true;
    }else{
        var ert=(json||{}).ert||"";
        if(ert&&(ert==='uptime-limit'||ert==='traffic-limit')){
            data[us]['C']=true;
        }
    }
setTimeout(function(){
    calcuPointsReq(a,k,data).then(resolve).catch(function(err){
        resolve([k,true,data]);
    });
}, 100);
})})
}else{return resolve([k,false,data])}}else{return resolve([k,false,data])}
})
}
function calcuPoints(){
var urls=[];
var pointsA={};
return getItemAll('_POINTS',{}).then(function(up){
return getItemAll('last_users',[]).then(function(data){
        for(var i in data){
            if(data[i]&&data[i]['u']&&data[i]['u']!=''&&typeof data[i]['C']=="undefined"){
                urls.push(data[i]['u']);
                if(up&&up[data[i]['u']]){
                    if(up[data[i]['u']]['pr']==''){
                        up[data[i]['u']]['pr']='nil';
                    }
                }else{
                    up[data[i]['u']]={pr:"nil"};
                }
            }
    }
    return calcuPointsReq(urls,0,data).then(function(e){
        var data=e[2];
        var isEr=e[1];
        var k=0
        for(var i in data){
            if(data[i]&&data[i]['u']&&data[i]['u']!=''&&typeof data[i]['C']=="undefined"){
                var us=data[i]['u'];
                var da=up[us];
                var pr=da.pr;
                if(pointsA[pr]){
                        if(pointsA[pr].indexOf(data[i]['u'])==-1){pointsA[pr].push(data[i]['u'])
                            k=k+1;
                        };
                    } else{
                        pointsA[pr]=[];
                        pointsA[pr].push(data[i]['u']);
                        k=k+1;
                    }
            }
        }
        return [pointsA,k,data];
    })
})})
}


















var collectiStart=false;
var last_users_EndsC=[];
function cheackCollect2(a,k){
return new Promise(function(resolve, reject){
if(a){if(typeof a=="object"&&a!=null&&a.length>0){
var ur=a[0];
a=a.slice(1);
doLoginReq(ur).then(function(json){
    var islog=json&&json.lin&&json.lin==="yes";
    if(islog){return resolve([k,'لديك رصيد بالفعل في الكرت'+'<p>'+json.usr])};
    k=k+1;
    var ert=(json||{}).ert||"";
    if(ert&&(ert==='uptime-limit' || ert==='traffic-limit' || isTrafficEnds(json) || isTimeEnds(json) || isDayesEnds(json))){
        if(us&&us!=""){
            for(var x in last_users){
                if(last_users[x]&&last_users[x]['u']==us){
                    last_users_EndsC.push(us);
                }
            }
        }
    }
    setTimeout(function(){
        cheackCollect2(a,k).then(resolve).catch(function(err){
            resolve([k,false]);
        })
    }, 100);
})
}else{return resolve([k,false])}}else{return resolve([k,false])}
})
}
function collecti(){
errElem.innerHTML='يرجى الانتظار ..';
showLoadingError();if(collectiStart){return collectiStart};
collectiStart=true;setTimeout(function(){collectiStart=false;}, 7000);
var urls=[];var urlsEnd=[];var urlsDone=[];var k=0;
var kCollect=jsonConfig.apps.kadamat['COLLECT']||3;
last_users_EndsC=[];
getsHotspotStatus().then(function(data){
    if(data&&data[0]){
        hotspotData=data[0];
    }
getItemAll('last_users',[]).then(function(data){
    for(var i in data){
        last_users=data;
        var isEnd =false,isDone=false;
        if (typeof data[i]['E'] != "undefined" && data[i]['E']){isEnd=true};
        if (typeof data[i]['E'] == "undefined"||void 0 == data[i]['E']){isEnd=false};
        if (typeof data[i]['C'] == "undefined"||void 0 == data[i]['C']){isDone=false} else{isDone=true};
        if (data[i]&&data[i]['u']&&data[i]['u']!=''){
            var ur='/json/login?username='+data[i]['u'];
            if(data[i]['p']&&data[i]['p']!=''){ur=ur+'&password='+data[i]['p']};
            if(data[i]['d']&&data[i]['d']!=''&&data[i]['r']){ur=ur+'&domain='+data[i]['d']};
            if(isDone){
                urlsDone.push('/json/login?username='+data[i]['u']+'!KADAMAT');
            } else{
                if(isEnd){
                    urlsEnd.push(ur);
                    k=k+1;
                } else{                   
                    urls.push(ur);
                    k=k+1;
                }
            }
        }
    };
    var isLogin=hotspotData['lin']&&hotspotData['lin']=='yes';
    if(isLogin){showErrorPopup('انت مسجل دخولك بالفعل');return showStatusPage('kadamat')};
    var mac=hotspotData['mac'];
    var us='C-'+mac;
    doLoginReq('/json/login?username='+us).then(function(json){
        var islog=json&&json.lin&&json.lin==="yes";
        if(islog){
            return getsHotspotStatus().then(function(data){
                var json2=data[0];
                if(data&&json2.usr==us){
                    showErrorPopup('لقد حصلت على كرت مجاني من خدمة اجمع واربح');
                    var mg1=" حصلت على "+hoursMToArabic(json2.time.sto)+" الرصيد "+remMegaToArabic(json2.bytes.rbt);
                    errElem.innerHTML+='<h4>'+mg1+'</h4>';
                    return showStatusPage('kadamat');
                } else{
                    if(k<kCollect){
                        showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kCollect+' كروت على الأقل خلال اخر اسبوع');
                        return showLoginPage('kadamat');
                     };
                    doLogOutReq();
                    showErrorPopup('لايمكنك استخدام الخدمة');
                }
            });
        } else{
            var ers=(json||{}).ers||"";
            var ero=(json||{}).ero||"";
            var ert=(json||{}).ert||"";
            if(ert&&(ert==='uptime-limit' || ert==='traffic-limit')){
                showErrorPopup(toArabicError(ers).replace('كرت','كرت مجاني')+"<p>"+'   يمكنك الحصول على كرت مجاني مرة واحدة في الاسبوع ')
                return showLoginPage(null);
            } else if(ert&&(ert==='invalid-mac')){
                showErrorPopup('  عذرا لايمكنك استخدام هذه الخدمة على هذا  الجهاز');
                return showLoginPage(null);
            } else {
                if(k<kCollect){
                    showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kCollect+' كروت على الأقل خلال اخر اسبوع');
                    return showLoginPage('kadamat');
                 };
                var urlsSol=[].concat(urls,urlsEnd,urlsDone);
                cheackCollect2(urlsSol.slice(0,kCollect+2),k).then(function(a){
                    var k2=a[0];
                    if(a[1]){showErrorPopup(a[1]);return showStatusPage('kadamat');};
                    getItemAll('last_users',[]).then(function(data){
                        for(var i in data){
                            if(data[i]&&data[i]['u']&&data[i]['u']!=""){
                                for (var x in last_users_EndsC){
                                    var usx=last_users_EndsC[x];
                                    if(usx==data[i]['u']){
                                        data[i]['E']=true;
                                        data[i]['C']=true;
                                    };
                                };
                            };
                        };
                        setItemAll('last_users',data);
                    });
                    doLoginReq('/json/login?username=COLLECT').then(function(json2){
                        var islog2=json2&&json2.lin&&json2.lin==="yes";
                        if(!islog2){showErrorPopup('عذرا هذة الخدمة متوقفة حاليا');return showLoginPage('kadamat');};
                        if(k2<kCollect){showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kCollect+' كروت على الأقل خلال اخر اسبوع');return showLoginPage('kadamat');};
                        var mac=hotspotData['mac'];
                        var us='C-'+mac;
                        doLoginReq('/json/login?username='+us).then(function(json){
                            var islog=json&&json.lin&&json.lin==="yes";
                            if(islog){
                                return getsHotspotStatus().then(function(data){
                                    var json2=data[0];
                                    if(data&&json2.usr===us){
                                        showErrorPopup('لقد حصلت على كرت مجاني من خدمة اجمع واربح');
                                        var mg1=" حصلت على "+hoursMToArabic(json2.time.sto)+" الرصيد "+remMegaToArabic(json2.bytes.rbt);
                                        errElem.innerHTML+='<h4>'+mg1+'</h4>';
                                        return showStatusPage('kadamat');
                                    } else{
                                        doLogOutReq();
                                        showErrorPopup('لايمكنك استخدام الخدمة');
                                    }
                                })
                            } else{
                                var ers=(json||{}).ers||"";
                                var ero=(json||{}).ero||"";
                                var ert=(json||{}).ert||"";
                                if(ert&&(ert==='uptime-limit' || ert==='traffic-limit')){
                                    showErrorPopup(toArabicError(ers).replace('كرت','كرت مجاني')+"<p>"+'   يمكنك الحصول على كرت مجاني مرة واحدة في الاسبوع ')
                                    return showLoginPage(null);
                                } else if(ert&&(ert==='invalid-mac')){
                                    showErrorPopup('  عذرا لايمكنك استخدام هذه الخدمة على هذا  الجهاز');
                                    return showLoginPage(null);
                                } else {
                                    showErrorPopup('لايمكنك استخدام الخدمة الا عند استخدام '+kCollect+' كروت على الأقل خلال اخر اسبوع');return showLoginPage('kadamat');
                                }
                            }
                        })
                    })
                })
            }
        }
    })
});
});
}
var allMacs={};
var allMacsA=[];
var allMacsT=0;
var allMacsIsTrue=false;
setTimeout(function(){
getItemAll('_POINTS',null).then(function(up){
    if(typeof up != "object"||up==null){up={}};
    for(var i in up){if(up[i]){
        var d =up[i]['d'];if(up[i]['d']&&(d+(35*24*60*60*1000))>getTimeNow(0)){
            if(i.indexOf(':')>-1){
                allMacs[i]=[];
                for(var b in up[i]){
                    if(up[i][b]&&up[i][b]>getTimeNow((1-(35*24*60*60*1000)))){
                        allMacs[i].push(b);
                        if(up[i][b]>allMacsT){
                            if(allMacsA.indexOf(i)==-1){var ar=[i].concat(allMacsA);allMacsA=ar;}
                            allMacsT=up[i][b];
                        } else{
                            if(allMacsA.indexOf(i)==-1){
                              allMacsA.push(i);
                            }
                        }
                }
            }
        }
    }
}
}
setTimeout(function(){
var m1='',m2='',m3='';
if(allMacsA.length>0){if(allMacs[allMacsA[0]].length>5){m1=allMacsA[0]}}
if(allMacsA.length>1){if(allMacs[allMacsA[1]].length>5){m2=allMacsA[1]}}
if(allMacsA.length>2){if(allMacs[allMacsA[2]].length>5){m2=allMacsA[2]}}
if(m1!=''){
    var us1='C-'+m1;
    doLoginReq('/json/login?username='+us1).then(function(json){
        if(m2!=''){
        setTimeout(function(){var us2='C-'+m2;doLoginReq('/json/login?username='+us2).then(function(json){
            if(m3!=''){
            setTimeout(function(){var us3='C-'+m3;doLoginReq('/json/login?username='+us3).then(function(json){
                if(json.lin==='yes'){
getsHotspotStatus().then(function(data){
    if(data&&data[1]){
        if(data[0].usr.indexOf('C-')>-1){
            if(loginApp.classList.contains('active')){
                showStatusPage(null);
            }
        }
    }})
                }
            })}, 500);
            }
        })}, 500);
        }
    })
}
}, 6000);
});
var btnK=document.querySelector('.app#login [data-goto="kadamat"]');
var btnA=document.getElementById('kadamat');
if(btnA){if(btnK){}else{if(document.querySelector('.app#login .buttons')){
    var el=document.createElement('button');
    el.className='btn';
    el.setAttribute('data-goto',"kadamat");
    el.setAttribute('onclick',"showApp(null,null,\'kadamat\')");
    el.innerHTML='الخدمات';
    document.querySelector('.app#login .buttons').appendChild(el);
}}}
}, 3000);
