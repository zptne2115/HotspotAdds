#!/usr/bin/env bash
set -eu
rm -rf dist
mkdir -p dist/public
cp index.html styles.css script.js manus-routes.json dist/
cp public/manus-routes.json public/extra5g-logo.svg dist/public/
cp -R public/fonts dist/public/
printf 'Static build ready in dist/\n'
