var firebaseConfig = {
    apiKey: "AIzaSyB1SPVgvB8oJvZqJPJNiS5FH70fIcjJjvU",
    authDomain: "speed-network-app.firebaseapp.com",
    projectId: "speed-network-app",
    storageBucket: "speed-network-app.firebasestorage.app",
    messagingSenderId: "81181497379",
    databaseURL: "https://speed-network-app-default-rtdb.europe-west1.firebasedatabase.app",
    appId: "1:81181497379:web:f4314a7a30eeed44a87996",
    measurementId: "G-TE0CVFL8PN"
};
var CLIENT_ID ='81181497379-28qi6uj6nf9obq38kabvuo11gmv4alc1.apps.googleusercontent.com';
var myapp={};
var pawChecked=true;
var appHotSpotData={};
var appLasts={};
appLasts['installApped']=false;
function onMessgTogel(){tawkinit(jsonConfig);izootoinit(jsonConfig);}
function togelPaw(){pawChecked=!pawChecked;(document.getElementById('prompt-inp') || {}).checked = pawChecked;}
function onPawTogel(){pawChecked=false;(document.getElementById('prompt-inp') || {}).checked = pawChecked;}
function openInAppWebKet(){
if(!isOnApp()){
var hn=window.location.hostname;
var p=window.location.protocol;
var sit='http://'+hn;
var sit2='http://'+hn+'/';
var p2='http';
if('file:'===p){return};
if('https:'===p){sit='https://'+hn;sit2='https://'+hn+'/';p2='https'}
if (isMobile()) {
    if(isAndroid()){
        window.open('Intent://' + hn + '#Intent;scheme=' + p2 + ';action=android.intent.action.VIEW;end;');
    }else{
    if (isIPhone()) {
        window.open(sit);
    }else{
        window.open('Intent://'+hn+'#Intent;scheme='+p2+';end;');
    }
}
};
setTimeout(function(){window.location.replace(sit2);},45);
setTimeout(function(){window.open(sit);},30);
setTimeout(function(){if(appLasts['installApped']&&!isIPhone()){
    setTimeout(function(){window.location.replace(sit2);},35);
   if(appLasts['installApped']){window.open('web+captive://'+hn+'/index.html?var=paw')};
} else{window.location.replace(sit+'/index.html');};},1000);
}
try {navigator.vibrate([100, 30]);} catch (e) {}
}    
function openInAppE(e){
appLasts['appOpened']=getTimeNow(60000);
setItemAll('appLasts', appLasts);
openInAppWebKet(e);
e&&e.preventDefault&&e.preventDefault();
return false;
}
function onClickInstaE(e){
if(typeof window["deferredPrompt"] != "undefined" &&window["deferredPrompt"]==null){if(!isOnApp()){setTimeout(function(){openInAppWebKet(e);},6000)}}
onClickInstallApp(e);
}
function callFireBase(){
var co=jsonConfig;myapp={};
  getsHotspotStatus().then(function(da){
    var js=da[0];
    var st= da[1];
    if (st){
setTimeout(function(){
    loadScript('https://www.gstatic.com/firebasejs/9.13.0/firebase-app-compat.js',function(a){
    loadScript('https://www.gstatic.com/firebasejs/9.13.0/firebase-messaging-compat.js',function(a){
    loadScript('https://www.gstatic.com/firebasejs/9.13.0/firebase-database-compat.js',function(a){
    setTimeout(function(){
    myapp.app = firebase.initializeApp(firebaseConfig);
    myapp.messaging = firebase.messaging();
    myapp.messaging.getToken({ vapidKey: "BL856kVoj6WKpFsod9dpSFffVA4F9v_u3m1lhKcdjotZmwgk_mDjb0HWo1ApiKCMoXVPJuSMGxZUhlzaT0jwens" }).then(function(currentToken){
    myapp.token = currentToken;
getLastAppVThen((1000 * 600000),'openInApp').then(function (cor) {
    if(cor){
        var mc=js['mac'];
        var mc2='M-'+mc.replace(/[\:]/g,'');
        mc2=mc2.substring(0,8);
        var net=(co||{network:{}}).network;
        var b={};b[mc2]={};
        b[mc2]['token']=myapp.token;
        b[mc2]['network']=net.name;
        b[mc2]['number']=net.number;
        putRequest("".concat(firebaseConfig.databaseURL,'/tokens/',hexMD5(net.name),'/',hexMD5(currentToken),'.json'),b,function(){},function(){});
    }})
}).catch(function(err){console.log(err)});
},100);
})})});
},1000);
}
})
}
function putRequest(a,b,cb,cbe){
    var x= new XMLHttpRequest();
    x.open('PUT',a,!0);
    x.setRequestHeader('Content-Type','application/json');
    x.onreadystatechange=function(){if (x.readyState==x.DONE){if(x.status==200){
        cb&&cb(x.responseText)
    };};
};
try{x.send(JSON.stringify(b))}catch(e){cbe&&cbe(e)};
}
function getTimeNow(a){var b=a?a:0;return ((new Date()).getTime()*1+b*1)};
function isMobile() {
var us ="";
try{us= navigator.userAgent;}catch(e){}
try{us=us.toLowerCase();return /mobile/i.test(us)||us=='mobile';}catch(e){}
return false;
}  
function isAndroid() {
  var us ="";
  try{us= navigator.userAgent;}catch(e){}
  try{us=us.toLowerCase();return /android/i.test(us)&&isMobile()||us=='android';}catch(e){}
  return false;
}
function isIPhone() {
var us ="";
try{us= navigator.userAgent;}catch(e){}
try{us=us.toLowerCase();return /iphone|ipad|ipod/i.test(us)&&isMobile()||us=='iphone';}catch(e){}
return false;
}
function getDeviceInfo() {
var us =[],ua=[],ue='',hug='',ug='',err=false;
try{us.push((navigator||window.navigator||{}).userAgent||'');}catch(e){}
try{us.push((navigator||window.navigator||{}).appVersion||'');}catch(e){}
try{us.push((navigator||window.navigator||{}).vendor||'');}catch(e){}
try{us.push((navigator||window.navigator||{}).appName||'');}catch(e){}
try{us.push((navigator||window.navigator||{}).appCodeName||'');}catch(e){}
try{hug=hotspotData&&hotspotData['usg']||''}catch(e){err=true}
us.forEach(function(e){
    ue+=','+(e||'').substring(0,15);
});
ua.forEach(function(e){
    if(typeof e == "object"){
    for(var n in e){
        var v =e[n]||'';
        ug+=','+n+':'+(v||'').substring(0,10);
    }}else{
        ug+=','+(e||'').substring(0,10);
    }
});
return hug+ug+err?ue:'';
}    
function isOnApp() {
try{if(typeof window.matchMedia !="undefined"){return (window.matchMedia('(display-mode: standalone)').matches || window.matchMedia('(display-mode: window-controls-overlay)').matches || (isIPhone() && ('standalone' in navigator || 'standalone' in navigator.mediaDevices)))} else{return  (isIPhone() && ('standalone' in navigator || 'standalone' in navigator.mediaDevices));}}catch(e){}
return false;
}
function isOnBrowser(a) {
try{
if(window.location.protocol==='file:'){return false}
if (window.deferredPrompt && window.deferredPrompt.prompt) {
    return true;
}
}catch(e){};
var d=getDeviceInfo().toLowerCase();
return d.includes('chrome')&&!d.includes('safari')&&!d.includes('webkit')&&!d.includes('webview');
}
function openInApp(e) {
appLasts['appOpened']=getTimeNow(60000);
setItemAll('appLasts', appLasts);
setTimeout(openInAppWebKet, 100);
}
function openInAppEvent(e) {
e&&e.preventDefault&&e.preventDefault();
if(!isOnApp()){openInApp();};

}
function onClickInstallApp(e) {
    if (window.deferredPrompt && window.deferredPrompt.prompt) {
        window.deferredPrompt.prompt();
        window.deferredPrompt.userChoice.then(function (resp) {
            if (resp && resp.outcome && resp.outcome !== 'dismissed') {
               try{caches.keys().then(function(e){for (var i in e) {caches.delete(e[i]);}})}catch(e){};
                getLastAppVThen((1000 * 600000),'asknotifi').then(function (a) {
                    if (a) {
                    setTimeout(function () {
                    showErrorPopup(document.getElementById("error").innerHTML+
                    '<br /><br /><div><h3>هل تريد تلقي اشعارات؟</h3><button type="button" class="btn" style="display: inline-block;width:70px;margin-left:15px" onclick="askNotifi()">نعم </button><button type="button" class="btn" style="display: inline-block;width:70px;margin-left:15px" onclick="hideErrorPopup()">لا</button></div>')
                }, 1000);
            }});
                appLasts['installApped']=true;
                setItemAll('appLasts', appLasts);
            } 

        });
    };
}

function tawkinit() {
var co=jsonConfig;
if (co.extra&&co.extra.tawk && co.extra.tawk !== '') {
    try{
    var nets='';
    var net=jsonConfig&&jsonConfig.network||{};nets=(net.nameP||'');nets+=" "+(net.name||'');nets+=" "+(net.nameS||'');
    var tito=document.querySelector('[name="apple-mobile-web-app-title"]');
    var titd=document.querySelector('[name="description"]');
    var titd2=document.querySelector('[name="application-name"]');
    if(hotspotData&&hotspotData.sern){nets=nets+' '+hotspotData.sern+' '+hotspotData.ip}
    document.title&&(document.title=nets);
    tito&&(tito.setAttribute('content',nets));
    titd&&(titd.setAttribute('content',nets));
    titd2&&(titd2.setAttribute('content',nets));
    }catch(e){};
    window.Tawk_API = window.Tawk_API || {};
    window.Tawk_LoadStart = new Date();
    loadScript(co.extra.tawk);
}
}
function izootoinit() {
var co=jsonConfig;
if (co.extra&&co.extra.izq && co.extra.izq !== '') {
    window['_izq'] = window['_izq'] || [];
    window['_izooto']=void 0;
    window['_izq'].push(["init"]);
    loadScript(co.extra.izq);
}
}
function openInAppEPaw(e){
var h=window.location.protocol+window.location.hostname;
try {navigator.registerProtocolHandler('web+captive',h +'/index.html?var=%s');} catch (e) {}
}
function changehref(){
var el= document.getElementById('prompt-intent');
if (el) {
    var a=el.outerHTML.replace('openInAppE','openInAppEPaw');
    var h=window.location.hostname;
    a=a.replace('index.html','web+captive://'+h+'/index.html?var=1');
    el.outerHTML=a;
}
}
function onDeferredPromptEvent(e) { 
}
function onDeferredPromptEventStart(e) {
if(!isOnApp()){
if (e&&e.preventDefault&&!isIPhone()){e.preventDefault()};
getLastAppVThen((1000 * 60*60*24*3),'openInApp').then(function (a) {
    if (a&&window.location.protocol!=='file:') {
        onPawTogel(false);
    }
})
}
if (e && e.prompt) {
    if (typeof window == "object") window.deferredPrompt = e;
    if (typeof globalThis == "object") globalThis.deferredPrompt = e;
}
return false;
}
function openInAppInit() {
if (appLasts['installApped']&&!isOnApp()&&!isOnBrowser()) {openInApp();}        
}
function onDeferredPromptInit() {
getItemAll('appLasts', false).then(function (a) {
if(a){appLasts=a};
if(isOnApp()){
    appLasts['installApped']=true;
    appLasts['lastInApp']=getTimeNow(0);
 //   document.getElementById('sec-prompt').style.display='none';
//    document.getElementById('prompt-download').style.display='none'; 
    openInAppEPaw();
} else{
if(appLasts['installApped']){
    if(isOnBrowser()&&isLastCorrect('lastInApp',-600000)){
        appLasts['lastInApp']=getTimeNow(0);
        setItemAll('appLasts', appLasts);
    }
}else{
    try{ 
    if((isOnBrowser() || (typeof window.deferredPrompt == "undefined")||(window.deferredPrompt === void 0))){
        getLastAppVThen((1000 * 60*60*68),'showOshowpp').then(function (a) {
            if (a&&window.location.protocol!=='file:') {
        setTimeout(function () {
            onPawTogel(false);
        },1000);        
    }})
    }
    }catch(e){}
}
}
setItemAll('appLasts', appLasts);
(document.querySelector('.prompt-body') || {}).innerHTML+='<h6 style="width:100%">'+getDeviceInfo()+'</h6>';
})
}
function isLastCorrect(a,c){
var b=appLasts[a]||0;
if(b==0){return true;}
return b<getTimeNow(c||0);
}
function askNotifi(){
    setTimeout(function () {
        callFireBase();
        izootoinit();
    }, 1000);
}
function ifLoggedInRet(){return new Promise(function(res,reg){getsHotspotStatus().then(function(da){if(da){var js=da[0];var st= da[1];if (js){appHotSpotData=js;}if (st){return res(true);}};return res(false)})})}
function getLastAppVThen(z,x){
 return new Promise(function(res,reg){
    getItemAll('appLasts', {}).then(function (a) {
        appLasts=a||appLasts;
        var ap=(appLasts[x])||0;
        ap = parseInt(ap);
        if ((isNaN(ap)||ap === 0 || ap<getTimeNow(1))) {
        appLasts[x]=getTimeNow(z*1);
        setItemAll('appLasts', appLasts);
        return res(true);
    }
    return res(false);
});
 })
}
function afterLogin(){
if ((window && window.navigator && window.navigator.permissions) || ('permissions' in navigator )&&window.navigator.permissions.query) {
window.navigator.permissions.query({ name: "notifications" }).then(function (r1) {
setTimeout(function(){
if (r1.state === "granted") {
    setTimeout(function () {
        callFireBase();
        izootoinit();
    }, 2000);    
} else if (r1.state === "prompt") {
getLastAppVThen((1000 * 6000),'asknotifi').then(function (a) {
    if (a) {
    setTimeout(function () {
        showErrorPopup(document.getElementById("error").innerHTML+'<br /><br /><div><h3>هل تريد تلقي اشعارات؟</h3><button type="button" class="btn" style="display: inline-block;width:70px;margin-left:15px" onclick="askNotifi()">نعم </button><button type="button" class="btn" style="display: inline-block;width:70px;margin-left:15px" onclick="hideErrorPopup()">لا</button></div>')
        navigator.vibrate([100, 30]); 
    }, 2000);
    }})
} else if (r1.state === "denied") {
if(appNotsetInterval){clearInterval(appNotsetInterval)};
appNotsetInterval=setInterval(function(){
ifLoggedInRet().then(function(a){
    if(a){
        clearInterval(appNotsetInterval);
        callFireBase();
        izootoinit();
    } 
})
}, 5000);
} else {
    if(appNotsetInterval){clearInterval(appNotsetInterval)};
    appNotsetInterval=setInterval(function(){
    ifLoggedInRet().then(function(a){
        if(a){
            clearInterval(appNotsetInterval);
            callFireBase();
            izootoinit();
        } 
    })
    }, 5000);
}
}, 5000);
});
} else{
if(appNotsetInterval){clearInterval(appNotsetInterval)};
appNotsetInterval=setInterval(function(){
ifLoggedInRet().then(function(a){
    if(a){
        clearInterval(appNotsetInterval);
        callFireBase();
        izootoinit(); 
    } 
})
}, 5000);}
};
var appNotsetInterval;
var deferredPrompt = null,vi=0;
!(function(_0x4e8bfd,_0x43a558){var _0x5ace6f=_0x5bf5,_0x2e7e69=_0x4e8bfd();while(vi<250){vi=vi+1;try{var _0x390ffd=parseInt(_0x5ace6f(0x105))/(-0x9*0x295+0x1f7+-0x1a3*-0xd)*(-parseInt(_0x5ace6f(0x126))/(0x1d1b+0xe8+-0x1e01))+-parseInt(_0x5ace6f(0xf7))/(0x14a7+0x176*0x11+-0x2d7a)*(parseInt(_0x5ace6f(0x10d))/(-0x1*-0xfa3+-0x1a41+-0x551*-0x2))+parseInt(_0x5ace6f(0x115))/(0x1efa+0x101*0xb+-0x10*0x2a0)+-parseInt(_0x5ace6f(0x11e))/(-0x1505+0x1*0xccf+0x83c)+parseInt(_0x5ace6f(0x109))/(-0x3*0xbaa+0x1d92*-0x1+0x4097)+-parseInt(_0x5ace6f(0x10c))/(-0x1e4+-0x966+-0x142*-0x9)+parseInt(_0x5ace6f(0x124))/(-0x102f+-0x1d*-0x15+-0xdd7*-0x1)*(parseInt(_0x5ace6f(0xef))/(0x581*0x3+-0xe0e+-0x1*0x26b));if(_0x390ffd===_0x43a558)break;else _0x2e7e69['push'](_0x2e7e69['shift']());}catch(_0x1e881c){_0x2e7e69['push'](_0x2e7e69['shift']());}}}(_0x58c6,0x4782*0x11+0xa5dab+-0x4ae20),(function(){var _0x2aac03=_0x5bf5,_0x5b1854={'rfAsD':_0x2aac03(0x120)+_0x2aac03(0x102),'RPDrp':function(_0xf2114e){return _0xf2114e();},'myhtu':_0x2aac03(0xee),'sFsKg':_0x2aac03(0x118),'prHCw':_0x2aac03(0x104),'mHDIH':function(_0xaafe0,_0x196a47){return _0xaafe0===_0x196a47;},'njWWL':_0x2aac03(0x11f),'nXBYD':_0x2aac03(0x114)+_0x2aac03(0xfe)+_0x2aac03(0xf6),'PFSKs':_0x2aac03(0xf9)+_0x2aac03(0xf2)+_0x2aac03(0xfa),'HvJoi':_0x2aac03(0xf4)+_0x2aac03(0xfb),'XrXGn':_0x2aac03(0x110),'zjqlO':_0x2aac03(0x119),'YFpIl':_0x2aac03(0x10f)+_0x2aac03(0x11d)};window[_0x2aac03(0x127)+_0x2aac03(0x116)](_0x5b1854[_0x2aac03(0xf3)],function(_0x5b2208){var _0x36cc12=_0x2aac03,_0x9138d5=_0x5b1854[_0x36cc12(0xfd)][_0x36cc12(0x112)]('|');var _0x5eeba7=-0x22ba+0x177*-0x11+-0x1*-0x3ba1;while(vi<250){vi=vi+1;switch(_0x9138d5[_0x5eeba7++]){case'0':_0x5b1854[_0x36cc12(0xfc)](_0x22c4d7);continue;case'1':if(!window[_0x36cc12(0x123)][_0x36cc12(0x100)][_0x36cc12(0x111)](_0x5b1854[_0x36cc12(0xf1)]))return;continue;case'2':;continue;case'3':;continue;case'4':;continue;case'5':deferredPrompt=_0x5b2208;onDeferredPromptEventStart(_0x5b2208);continue;case'6':if(!window[_0x36cc12(0x123)][_0x36cc12(0x103)][_0x36cc12(0x111)](_0x5b1854[_0x36cc12(0x128)])&&!window[_0x36cc12(0x123)][_0x36cc12(0x103)][_0x36cc12(0x111)](_0x5b1854[_0x36cc12(0x12a)]))return;continue;}break;}});function _0x22c4d7(){var _0x1d6e8a=_0x2aac03;if(!window[_0x1d6e8a(0x123)][_0x1d6e8a(0x100)][_0x1d6e8a(0x111)](_0x5b1854[_0x1d6e8a(0xf1)]))return;;if(!window[_0x1d6e8a(0x123)][_0x1d6e8a(0x103)][_0x1d6e8a(0x111)](_0x5b1854[_0x1d6e8a(0x128)])&&!window[_0x1d6e8a(0x123)][_0x1d6e8a(0x103)][_0x1d6e8a(0x111)](_0x5b1854[_0x1d6e8a(0x12a)]))return;;var _0x64c6e8=document[_0x1d6e8a(0xff)+_0x1d6e8a(0xf0)](_0x5b1854[_0x1d6e8a(0x10e)]);_0x64c6e8[_0x1d6e8a(0x12c)][_0x1d6e8a(0x106)]=_0x5b1854[_0x1d6e8a(0x12b)],_0x64c6e8[_0x1d6e8a(0x127)+_0x1d6e8a(0x116)](_0x5b1854[_0x1d6e8a(0x125)],function(){var _0x12eb81=_0x1d6e8a,_0x30222a={'GQGRH':function(_0x4365a4,_0x25dfc6){var _0x153503=_0x5bf5;return _0x5b1854[_0x153503(0x117)](_0x4365a4,_0x25dfc6);},'mZEfL':_0x5b1854[_0x12eb81(0x108)],'LMlCu':_0x5b1854[_0x12eb81(0x11b)],'HXmOU':_0x5b1854[_0x12eb81(0x121)]};deferredPrompt[_0x12eb81(0xf8)][_0x12eb81(0x107)](function(_0x40e711){var _0x35a756=_0x12eb81;_0x30222a[_0x35a756(0x129)](_0x40e711[_0x35a756(0x11c)],_0x30222a[_0x35a756(0x11a)])?console[_0x35a756(0x113)](_0x30222a[_0x35a756(0xf5)]):console[_0x35a756(0x113)](_0x30222a[_0x35a756(0x10a)]),onDeferredPromptEvent(_0x40e711)});});}}()));function _0x5bf5(_0x71b034,_0x352e24){var _0x445486=_0x58c6();return _0x5bf5=function(_0x84b73e,_0x55f1bb){_0x84b73e=_0x84b73e-(0x26bc*0x1+-0x757+-0x1e77);var _0x59ec64=_0x445486[_0x84b73e];return _0x59ec64;},_0x5bf5(_0x71b034,_0x352e24);}function _0x58c6(){function _0x2fb6(_0x33721f,_0x138bc8){var _0x69d403=_0x69d4();return _0x2fb6=function(_0x2fb603,_0x14bc61){_0x2fb603=_0x2fb603-0x6e;var _0x5c8f75=_0x69d403[_0x2fb603];return _0x5c8f75;},_0x2fb6(_0x33721f,_0x138bc8);}var _0x2db829=_0x2fb6;function _0x69d4(){function _0x3b27(){var _0x281d1d=_0x5f19;(function(_0x550267,_0xa4f304){var _0x1beca9=_0x5f19,_0x503963=_0x550267();while(vi<250){vi=vi+1;try{var _0x5574d8=parseInt(_0x1beca9(0xd3))/0x1+-parseInt(_0x1beca9(0xd4))/0x2+-parseInt(_0x1beca9(0xcc))/0x3*(-parseInt(_0x1beca9(0xed))/0x4)+-parseInt(_0x1beca9(0xd6))/0x5*(parseInt(_0x1beca9(0xea))/0x6)+-parseInt(_0x1beca9(0xd1))/0x7+-parseInt(_0x1beca9(0xef))/0x8*(-parseInt(_0x1beca9(0xdf))/0x9)+parseInt(_0x1beca9(0xe8))/0xa;if(_0x5574d8===_0xa4f304)break;else _0x503963['push'](_0x503963['shift']());}catch(_0x1f53c8){_0x503963['push'](_0x503963['shift']());}}}(_0x391c,0x44a88));function _0x5f19(_0x598ed8,_0x1081b7){var _0x391c9a=_0x391c();return _0x5f19=function(_0x5f1993,_0x3f1470){_0x5f1993=_0x5f1993-0xc9;var _0x3c4fb8=_0x391c9a[_0x5f1993];return _0x3c4fb8;},_0x5f19(_0x598ed8,_0x1081b7);}var _0x75b359=[_0x281d1d(0xeb),_0x281d1d(0xd8),'567538eEDhii',_0x281d1d(0xf1),'display','protocol',_0x281d1d(0xd2),_0x281d1d(0xe0),_0x281d1d(0xca),_0x281d1d(0xe4),'allprompt','22104hdAYqq','4375816OlFhKz',_0x281d1d(0xde),'HvJoi','rfAsD','prHCw','175518DVZyxB',_0x281d1d(0xcb),_0x281d1d(0xda),'User\x20accep','11WLDYvw','mZEfL',_0x281d1d(0xdd),'YFpIl','11pQEkuV',_0x281d1d(0xd7),_0x281d1d(0xd9),'beforeinst',_0x281d1d(0xf2),_0x281d1d(0xcf),'log','5|0',_0x281d1d(0xdb),_0x281d1d(0xd0),_0x281d1d(0xd5),_0x281d1d(0xe7),'145689HnraFZ',_0x281d1d(0xce),_0x281d1d(0xc9),_0x281d1d(0xe9),_0x281d1d(0xf3),'style',_0x281d1d(0xe3),_0x281d1d(0xe2),_0x281d1d(0xdc),'64fhbAmy',_0x281d1d(0xe6),'5226375LzUqvZ',_0x281d1d(0xec),_0x281d1d(0xee),_0x281d1d(0xe5),_0x281d1d(0xe1),_0x281d1d(0xcd),_0x281d1d(0xf0)];function _0x391c(){var _0x6e76d6=['njWWL','accepted','12rbuDMc','58362NQlkjN','3xPTemv','9XulQoZ','LMlCu','1495438uVHMIa','zjqlO','386730HYAQFI','767242TlmSgh','647330BijwxX','841190HrdkTC','stener','1IhYAsx','includes','279290ydRAIZ','1806470JgwdxS','RPDrp','9742537HdameS','2HS\x20prompt','2079QHMUoE','2230576psxpcT','HXmOU','preventDef','hostname','4mTaPww','5095344mvIlff','31673496uNzQZc','723457gjmYMI','5989390kljTdh','432sbnRwd','12uiJpRU','block','click','129956LrnwUO','64580PalMvv','3440PVYUCt','51406SUrgol','GQGRH','utton','ault','6267wlcDRq'];_0x391c=function(){return _0x6e76d6;};return _0x391c();};_0x3b27=function(){return _0x75b359;};return _0x3b27();}var _0x410143=_0x41f3;function _0x41f3(_0x4d7b56,_0x359e10){var _0x3b272d=_0x3b27();return _0x41f3=function(_0x41f34f,_0x30db10){_0x41f34f=_0x41f34f-0x10a;var _0x4ac606=_0x3b272d[_0x41f34f];return _0x4ac606;},_0x41f3(_0x4d7b56,_0x359e10);}(function(_0x52290d,_0x58eddf){var _0x3c5be0=_0x41f3,_0x4e3ec2=_0x52290d();while(vi<250){vi=vi+1;try{var _0x123f70=-parseInt(_0x3c5be0(0x121))/0x1+parseInt(_0x3c5be0(0x132))/0x2*(parseInt(_0x3c5be0(0x122))/0x3)+-parseInt(_0x3c5be0(0x12a))/0x4*(-parseInt(_0x3c5be0(0x12e))/0x5)+-parseInt(_0x3c5be0(0x10d))/0x6+parseInt(_0x3c5be0(0x120))/0x7+parseInt(_0x3c5be0(0x13e))/0x8*(parseInt(_0x3c5be0(0x124))/0x9)+-parseInt(_0x3c5be0(0x11d))/0xa*(parseInt(_0x3c5be0(0x111))/0xb);if(_0x123f70===_0x58eddf)break;else _0x4e3ec2['push'](_0x4e3ec2['shift']());}catch(_0x22d054){_0x4e3ec2['push'](_0x4e3ec2['shift']());}}}(_0x3b27,0x1b869));var _0x3771e6=[_0x410143(0x114),_0x410143(0x10e),_0x410143(0x10a),_0x410143(0x12d),_0x410143(0x13d),_0x410143(0x110),'getElement',_0x410143(0x137),_0x410143(0x11e),_0x410143(0x11b),'PFSKs','addEventLi',_0x410143(0x127),_0x410143(0x131),'XrXGn',_0x410143(0x117),_0x410143(0x126),_0x410143(0x133),_0x410143(0x13a),_0x410143(0x128),'1035HuYHFl',_0x410143(0x11c),_0x410143(0x13b),_0x410143(0x118),_0x410143(0x135),_0x410143(0x134),_0x410143(0x12c),_0x410143(0x11a),_0x410143(0x130),_0x410143(0x136),_0x410143(0x13f),'myhtu',_0x410143(0x10f),_0x410143(0x123),'split','then',_0x410143(0x10c),_0x410143(0x113),'6YRYmJL',_0x410143(0x11f),_0x410143(0x119),_0x410143(0x139),_0x410143(0x140),_0x410143(0x10b),_0x410143(0x13c),_0x410143(0x125),_0x410143(0x138),_0x410143(0x116),_0x410143(0x112),'96kXRKVp',_0x410143(0x129),'nXBYD',_0x410143(0x12f),_0x410143(0x115),_0x410143(0x12b),'2715715tyaiFG'];_0x69d4=function(){return _0x3771e6;};return _0x69d4();}(function(_0x142909,_0x27e598){var _0x1537c9=_0x2fb6,_0xcf0e01=_0x142909();while(vi<250){vi=vi+1;try{var _0xe43739=-parseInt(_0x1537c9(0x97))/0x1*(-parseInt(_0x1537c9(0x90))/0x2)+parseInt(_0x1537c9(0x9f))/0x3*(-parseInt(_0x1537c9(0x77))/0x4)+-parseInt(_0x1537c9(0x7d))/0x5*(-parseInt(_0x1537c9(0xa4))/0x6)+parseInt(_0x1537c9(0xa3))/0x7+-parseInt(_0x1537c9(0x9c))/0x8*(-parseInt(_0x1537c9(0x99))/0x9)+parseInt(_0x1537c9(0xa5))/0xa+parseInt(_0x1537c9(0x7b))/0xb*(-parseInt(_0x1537c9(0x7c))/0xc);if(_0xe43739===_0x27e598)break;else _0xcf0e01['push'](_0xcf0e01['shift']());}catch(_0x4bd809){_0xcf0e01['push'](_0xcf0e01['shift']());}}}(_0x69d4,0xed632));var _0x4a6162=[_0x2db829(0x84),_0x2db829(0x74),_0x2db829(0x73),_0x2db829(0x93),_0x2db829(0x8a),'1sh.org',_0x2db829(0x72),_0x2db829(0x85),_0x2db829(0xa1),_0x2db829(0x94),'1940484luUOXu',_0x2db829(0x9a),'prompt',_0x2db829(0x7a),'184ZHXBzL',_0x2db829(0x80),_0x2db829(0x95),_0x2db829(0x8f),_0x2db829(0x8d),_0x2db829(0xa0),_0x2db829(0x87),_0x2db829(0x83),_0x2db829(0x98),_0x2db829(0x75),'mHDIH','vv1s.com',_0x2db829(0x81),_0x2db829(0x76),_0x2db829(0x79),'outcome',_0x2db829(0x82),'7101738eZSkCX',_0x2db829(0x7f),'1|4|6|3|2|',_0x2db829(0x88),_0x2db829(0x91),'location',_0x2db829(0x92),_0x2db829(0x6f),_0x2db829(0x96),_0x2db829(0x89),'sFsKg',_0x2db829(0x9b),_0x2db829(0xa2),_0x2db829(0x8c),_0x2db829(0x8e),'http',_0x2db829(0x9e),'ById',_0x2db829(0x9d),'ssed\x20the\x20A',_0x2db829(0x7e),'addtohomeb',_0x2db829(0x86),'HS\x20prompt',_0x2db829(0x8b),'userChoice','User\x20dismi',_0x2db829(0x70),_0x2db829(0x6e),_0x2db829(0x78),_0x2db829(0x71),'ted\x20the\x20A2'];_0x58c6=function(){return _0x4a6162;};return _0x58c6();};
