var chaptry=0;
var whenKick={};
var getRateDone=true;
var hotspotData={};
var setIntervalStatusQury;
var osamaSpeedName='';
var osamaSpeedUser='';
var osamaSpeedValue='';
var osamaSpeedIndex=0;
var osamaUpdateChecked=0;
var last_users =[];
var speed_check={};
var speed_change={};
var speed_last={};
var statusEls={};
var isNewUser=false;
var isNewLogin=false;
var updates=document.getElementById('updates');
var updates2=document.getElementById('updates2')||updates;
var loginFormOnSubmitDialog22=true;
var loginFormOnSubmitDialog=true;
var us='';
function getDateStr(a){var d=a;if(typeof a === "number" || typeof a ==="string" || void 0==a){d=new Date(a)};var m=d.getMonth()*1+1;var o=''.concat(d.getDate(),'-',m,'-',d.getFullYear());return o;}
function toBoolen(a){if(typeof a!="undefined"&&typeof a!=null){if(typeof a == "boolean"){return a};if(typeof a == "number"&&isNaN(a)){return false};if(a=="") {return false};a="".concat(a);a=a.toLowerCase();return (a=="true"||a=="yes"||a=="1");} else return false;}
function fillStatusDetails(json){
var attr=json&&json.attr||{days:"",group:"",rate:"",addr:"",messg:""};
var ds=attr.days&&attr.days!=""?attr.days:"";
var pr=attr.group||"";
var na=attr.rate||"";
var addr=attr.addr||"";
var up=(updates&&updates.checked)?"<p style='color:red;font-size: 10px;'> (التحديثات موقفة) </p>":"";
var sprad=json&&json['dom']||"";
osamaSpeedUser=getLastUs(json);
var us=osamaSpeedUser;
if(sprad&&sprad!=""){
if(sprad.indexOf('_OFF')>-1){
if(updates){updates.checked=true;}
if(updates2){updates2.checked=true;}
up="<p style='color:red;font-size: 10px;'> (التحديثات موقفة) </p>";
sprad=sprad.split('_')[0];
} else{
if(updates){updates.checked=false;}
if(updates2){updates2.checked=false;}  
up='';
}
if(isSPD(null)){try {
var speedsV=jsonConfig.login.speeds;var ext=getStatusExtra(hotspotData);if(ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){speedsV=ext['CN']};
if(typeof speedsV !="object"||typeof speedsV['SPN'] !="object"||speed_change[us]&&speed_change[us]['SPN']&&speed_change[us]['SPN'].length){speedsV=speed_change[us]};var spdV=speedsV['SPD']||[""];var spnV=speedsV['SPN']||[""];var spd='';var spn='';spdV.forEach(function(e,i){if(e==sprad){spd=e;spn=spnV[i];}});if(spn&&spn!=""){na=spn;}} catch (e) {}}

}
if(ds&&ds!=""){
var d=daysToArabic(ds);
if(d&&d!=""&&daysV){
daysV.innerHTML=d;
daysA.style.display='';
}}
profileV.innerHTML=pr;
if(profileV&&profileA&&pr&&pr!=""&&pr!="."&&pr!=".."&&pr!="..."){
profileV.innerHTML=pr;
profileA.style.display='';
} else{
if(addr&&addr.includes('PR_')&&profileV){
var pr=addr.split('PR_')[1];
if(profileA&&profileV&&pr&&pr!=""){
profileV.innerHTML=pr;
profileA.style.display='';
}}}
if(speedV&&(na&&na!=""||up!="")){
speedV.innerHTML=''.concat(na,up);
speedA.style.display='';
};
}
function getStatusProfile(a){
var json=a&&a!=null?a:hotspotData;
var attr=json.attr||{days:"",group:"",rate:"",addr:"",messg:""};
var grop=attr&&attr['group']||"";
var addrArr;
try{
addrArr=getStatusExtra(json);
if(addrArr['PR']){if(grop&&(grop.includes('0r')||grop.includes('0R')||grop.includes('0YR'))&&(!addrArr['PR'].includes('0r')&&!addrArr['PR'].includes('0R')&&!addrArr['PR'].includes('0YR'))){}else{grop=addrArr['PR']}};
}catch(e){};
try{
if(typeof grop == "undefined" || grop==null || grop==""){
if(json.time&&json.time.rto&&json.time.rto!=""&&json.time.rto.indexOf('s')>-1&&json.time.rto.indexOf('m')>-1){
var dp=parseInt(json.secs.rto);
if(dp>=60){
dp=json.time.rto.split('m')[0];
dp=dp.replace('m','');
dp=dp.replace('h','');
dp=dp.replace('d','');
dp=parseInt(dp);
if(!isNaN(dp)){
dp=(dp*100);
grop=''.concat(dp,' ريال ');
}}}};
}catch(e){};
return grop;
}
function getStatusExtra(a){
var json=a&&a!=null?a:hotspotData;
var attr=json.attr||{days:"",group:"",rate:"",addr:"",messg:""};
var isRad=isRadius(json);
var addrArr ={};
var out ={};
try{var addr=attr.addr||"";if(addr.indexOf('=')>-1){var addrrr=''.concat(addr,'_');var ad=addrrr.split('_');addrArr={};for(var n in ad){var adi=ad[n];if(adi.indexOf('=')>-1){var adnr =adi.split('=');addrArr[adnr[0]]=adnr[1];}}};}catch(e){};
if(isRad==0){
if(json&&json.time&&json.time.ito&&json.time.ito.indexOf('s')>-1){
    var s =json.time.ito;
    if (typeof jsonConfig=="object"&&jsonConfig.apps&&jsonConfig.apps.status&&jsonConfig.apps.status[s]){
 addrArr['CF']=s;
    }}} 
if (typeof attr=="object"){for(var n in attr){var v=attr[n];out[n]=v;}};
if (typeof addrArr=="object"){for(var n in addrArr){var v=addrArr[n];out[n]=v;}};
if (typeof attr=="object"&&attr.group&&attr.group!=""){
    if (typeof addrArr=="object"&&addrArr['CF']){

    }else{
     addrArr['CF']=attr.group;
    }}
if (typeof addrArr=="object"&&addrArr['CF']&&jsonConfig&&jsonConfig.apps&&jsonConfig.apps.status&&typeof jsonConfig.apps.status[addrArr['CF']]=="object"){
    for(var n in jsonConfig.apps.status[addrArr['CF']]){var v=jsonConfig.apps.status[addrArr['CF']][n];out[n]=v;};out['CN']=jsonConfig.apps.status[addrArr['CF']];
} else if (typeof addrArr=="object"&&addrArr['PR']&&jsonConfig&&jsonConfig.apps&&jsonConfig.apps.status&&typeof jsonConfig.apps.status[addrArr['PR']]=="object"){
    for(var n in jsonConfig.apps.status[addrArr['PR']]){var v=jsonConfig.apps.status[addrArr['PR']][n];out[n]=v;};out['CN']=jsonConfig.apps.status[addrArr['PR']];
}
if (typeof addrArr=="object"){for(var n in addrArr){var v=addrArr[n];out[n]=v;}};
return out;
}    

function getStatusDayes(a){
var json=a&&a!=null?a:hotspotData;
var attr=json.attr||{days:"",group:"",rate:"",addr:"",messg:""};
var exdate=attr&&attr['days']||"";
var days=-1;
var kadamat='';
var kadamatPL='';
var addrArr={};
try{
addrArr=getStatusExtra(json);
if(addrArr['DA']){days=parseInt(addrArr['DA'])};
if(addrArr['HA']){var ts=(parseInt(json.secs.sto)*1+parseInt(json.secs.ut)*1+(60*60));exdate=getTimeNow(ts*1000);days=(ts/(24*60*60)).toFixed(0)};
if(addrArr['KA']){kadamat=addrArr['KA']};
if(addrArr['PL']){kadamatPL=addrArr['PL']};
}catch(e){};
try{
if((typeof exdate == "undefined" || exdate==null || exdate==='')&&days<0&& typeof addrArr['DA']==="undefined"){
if(json.time&&json.time.rto!=""&&json.time.rto.indexOf('s')>-1&&json.time.rto.indexOf('m')>-1){
var dp=parseInt(json.secs.rto);
if(dp>=60){
dp=(dp % 60);
dp=parseInt(dp);
if(!isNaN(dp)){
days=(dp*1);
};
};
} else{
if(json.secs&&json.secs.sto){
var t1=parseInt(json.secs.sto)+parseInt(json.secs.ut)+60*60;
if(t1>(24*60*60*7)){
var da=(t1/(24*60*60)).toFixed(0);
if(da>(24*60*60*7)){days=da}}}}};
}catch(e){};
var ex=false;
try{
if(typeof exdate != "undefined"&&exdate!=""){
var d=new Date(exdate);
exdate=d.getTime();
ex=true;
}else{
if(days>0){
var d=new Date();
exdate=(days*24*60*60*1000)+d.getTime();
} else{
var ap=jsonConfig.apps;
var ps=jsonConfig.prices;
var myprs='';
if(ap.prices){ps=ap.prices};
if(ps&&typeof ps.content == "object"&&ps.content){
myprs=getStatusProfile(a);
if (myprs&&myprs!=""){
if(myprs){myprs=myprs.replace(/\s/,'');};
if(myprs){myprs=myprs.replace('ريال','');};
if(myprs){myprs=myprs.replace('Y','');};
if(myprs){myprs=myprs.replace('y','');};
if(myprs){myprs=myprs.replace('r','');};
if(myprs){myprs=myprs.replace('R','');};
if(myprs){myprs=myprs.replace(/[^0-9]/g,'');};
ps.content.forEach(function(e){
var prs=e.price||e.title||'';
if(prs){prs=prs.replace(/\s/,'');};
if(prs){prs=prs.replace(/[^0-9]/g,'');}
if(prs==myprs){
if(e.body){
e.body.forEach(function(e1){
if(e1){e1=e1.replace(/\s/,'');};
if(e1.includes('سبوعين')){days=14} else
if(e1.includes('سبوع')){days=7}else
if(e1.includes('شهر')){days=30}else
if(e1.includes('يومان')){days=2}else
if(e1=="يوم"){days=1}else{  
if(e1){days=e1.replace(/[^0-9]/g,'');};
}})
}else{
var e1=e.validity;
if(e1){e1=e1.replace(/\s/,'');};
if(e1.includes('سبوعين')){days=14} else
if(e1.includes('سبوع')){days=7}else
if(e1.includes('شهر')){days=30}else
if(e1.includes('يومان')){days=2}else
if(e1=="يوم"){days=1}else{  
if(e1){days=e1.replace(/[^0-9]/g,'');};
}}}});
days=parseInt(days)*1;
if(days>0){
var d=new Date();
exdate=(days*24*60*60*1000)+d.getTime();
}}}}}}catch(e){};
return [days,exdate,ex];
}
function fillSpeed2(ss,a){
var json=a&&a!=null?a:hotspotData;
var us=getLastUs(json);
var speedch=ss||{};
var attr=json.attr||{days:"",group:"",rate:"",addr:"",messg:""};
var isRad=isRadius(json);
var dom=json&&json['dom']||"";
var grop=getStatusProfile(a);
var kadamat='';
var kadamatPL='';
var mk=json.mac||'';
try{
var addr=attr.addr||"";var addrArr;
if(addr.includes('=')){
var addrrr=''.concat(addr,'_');
var ad=addrrr.split('_');
addrArr={};
for(var n in ad){
var adi=ad[n];
if(adi.includes('=')){
addrArr[adi.split('=')[0]]=adi.split('=')[1];
}}
if(addrArr['KA']){kadamat=addrArr['KA']};
if(addrArr['PL']){kadamatPL=addrArr['PL']};
};
}catch(e){};
if(kadamat=="FRI"){
    if(kadamatPL>0){
 if(isNewUser==us){
    setTimeout(function(){
  showErrorPopup('  مبرووك حصلت على زيادة مجانية  '.concat( kadamatPL , "%"));     
    }, 3000);
 };
 grop=''.concat(grop,' عرض الجمعة ','<h5 style="color:green">','  مبرووك حصلت على زيادة مجانية  ', kadamatPL , "%");
    }}
if(kadamat=="COL"){
    if(kadamatPL>0){
 if(isNewUser==us){
    setTimeout(function(){
  showErrorPopup("<span style='color:green'>مبرووك حصلت  على كرت مجاني من خدمة اجمع واربح");     
    }, 3000);
 };
 grop=''.concat(grop,' خدمة اجمع واربح ','<h5 style="color:green">',' مبرووك حصلت  على كرت مجاني من خدمة اجمع واربح ');
    }}
if(kadamat=="SOL"){
    if(kadamatPL>0){
 if(isNewUser==us){
    setTimeout(function(){
  showErrorPopup("<span style='color:green'>مبرووك حصلت  على كرت مجاني من خدمة اجمع واربح");     
    }, 3000);
 };
 grop=''.concat(grop,' خدمة  سلفة ','<h5 style="color:green">','  حصلت  على كرت سلفة     ');
    }}
var daa=getStatusDayes(a);
var days=daa[0];
var exdate=daa[1];
if(dom==''){dom=(attr.rate||"");dom=dom.toUpperCase();}
var spd=osamaSpeedValue;
var spn=osamaSpeedName;
var spx=osamaSpeedIndex*1;
var upd=osamaUpdateChecked;
try{speedch=ss||jsonConfig.login.speeds||null;}catch(e){}
try{
if(isRad){
if(isSPD(speedch)&&dom&&dom!=""){
if(dom.indexOf('OFF')>-1){spd=dom.split('_')[0];upd=1} else{spd=dom;upd=0};
if(speedch['SPD'].indexOf(spd)>-1){spx=speedch['SPD'].indexOf(spd);if(spx>-1){spn=speedch['SPN'][spx]}};
};
} 
}catch(e){};
if(upd==-1){upd=updates&&updates.checked?1:0};
var up=upd?"<p style='color:red;font-size: 10px;'> (التحديثات موقفة) </p>":"";
if(spn&&spn!=""){
speedV.innerHTML=''.concat(spn,up);
speedA.style.display='';
} else{
if(speedV.innerHTML==""){speedA.style.display='none'};
}
if(profileA&&profileV&&grop&&grop!=""){
profileV.innerHTML=grop;
profileA.style.display='';
} else{
if(profileA&&profileV&&profileV.innerText===""){
profileA.style.display='none'
};
};
if(us.indexOf(':')==-1){
getItemAll('_POINTS',null).then(function(up){
if(typeof up != "object"||up==null){up={}};
if(typeof up[us]!= "string"){
if(typeof up[mk]!= "object"){up[mk]={};}
var obj={};
var li=0;
for(var i in up){if(up[i]){var d =up[i]['d'];if((d*1+35*24*60*60*1000)>getTimeNow(0)&&li<19){obj[i]={};var lie=0;for(var ie in up[i]){var d =up[ie];if((d*1+35*24*60*60*1000)>getTimeNow(0)&&lie<19){obj[i][ie]=up[i][ie];lie=lie+1}};}}};
if(typeof obj[mk]!= "object"){obj[mk]={};};
obj[mk][us]=getTimeNow(0);
obj[mk]['d']=getTimeNow(0);
obj[us]={d:getTimeNow(0),pr:grop,da:days,ex:exdate};
}
if(typeof obj[mk]!= "object"){obj[mk]={};};
if(typeof obj[us]!= "object"){obj[us]={};};
obj[mk][us]=getTimeNow(0);
obj[mk]['d']=getTimeNow(0);
obj[us]['d']=getTimeNow(0);
setItemAll('_POINTS',obj);
})
getItemAll('_dayes',null).then(function(up){
if(typeof up != "object"||up==null){up={}};
var mess=' تاريخ اول استخدام  ';
var df,de,isn=false;
var ts=getTimeNow(-1000*60*60*6);
if(typeof up[us]=== "object"){
df=up[us]['f'];
de=up[us]['d'];
if(typeof exdate != "undefined"&&exdate!=""){
var d=new Date(exdate);
de=d.getTime();
mess=' تاريخ الانتهاء  ';
}} else{
df=getTimeNow(0);
if(days>0&&(typeof exdate == "undefined" || exdate=="")){
de=(days*24*60*60*1000)+df*1+60000*1;
mess=' تاريخ اول استخدام  ';
} else if(typeof exdate != "undefined"&&exdate!=""){
var d=new Date(exdate);
de=d.getTime();
mess=' تاريخ الانتهاء  ';
} else if(days>0){
de=(days*24*60*60*1000)+df*1+60000*1;
mess=' تاريخ اول استخدام  ';
} else{
de=df;
mess=' تاريخ اول استخدام  ';
}
isn=true;
}
if(!isn){
if(ts>de){de=df};
if(de==df){mess=' تاريخ اول استخدام  ';}};
if(json&&json.secs&&json.secs.sto&&json.secs.sto!=''&&json.secs.sto!='0'&&(typeof exdate == "undefined" || exdate=="")){
var ts=parseInt(json.secs.sto);
if(isNaN(ts)){ts=0}
if(ts>0&&ts>(60*60*24*7)){
var d=new Date();
var td=d.getTime();
ts=(ts*1000)+td*1+600000;
if(ts>de){de=(ts*1)+600000};
} 
};
if(de!=df&&daysA){
var d=daysToArabic(de+600000);
var d2=new Date(df);
var m=d2.getMonth()*1+1;
var dd=''.concat(d2.getDate(),'-',m,'-',d2.getFullYear());
daysV.innerHTML=''.concat(d,"<p style='color:green;font-size: 10px;'>تاريخ اول استخدام  ".concat(dd,"</p>"));
daysA.style.display='';
} else{
if(daysA){
var d2=new Date(df);
var m=d2.getMonth()*1+1;
var dd=''.concat(d2.getDate(),'-',m,'-',d2.getFullYear());
daysV.innerHTML=''.concat(dd,"<p style='color:green;font-size: 10px;'>".concat(mess,"</p>"));
daysA.style.display='';
}};
var obj={};
var li=0;
for(var i in up){if(up[i]){var d =up[i]['d'];if((d+(7*24*60*60*1000))>getTimeNow(0)&&li<12){obj[i]=up[i];li++}}};
obj[us]={m:mess,d:de,f:df};
setItemAll('_dayes',obj);
});
}}
function getStatusQury(){
getsHotspotStatus().then(function(data){
if(data){
var json=data[0];
var isLogin=data[1];
if(json==null){
showLoginPage(null);
try{clearInterval(setIntervalStatusQury);}catch(e){};
} else{
if(!isLogin){
showLoginPage(null);
try{clearInterval(setIntervalStatusQury);}catch(e){};
return;
};
us=getLastUs(json);
var usm=usedMegaToArabic(''.concat(json.bytes.bi,",",json.bytes.bo));
var usmu=usedMegaToArabic(json.bytes.bi);
var usmd=usedMegaToArabic(json.bytes.bo);
var ush=hoursArabic(json.time.ut);
var attr=json.attr||{days:"",group:"",rate:"",addr:"",messg:""}
try{
if(attr&&attr.messg&&attr.messg!=""&&attr.messg.indexOf('%')>-1){
var msg='{"msg":"'.concat(attr.messg,'"}');
if(typeof osamaDecodeAr != "undefined"){msg=osamaDecodeAr(msg,true)} else{msg=decodeURIComponent(msg)};
var mess=JSON.parse(msg);
if(mess.up&&mess.up!=""&&mess.up!="0"){
usmu=usedMegaToArabic(parseInt(mess.up)+parseInt(json.bytes.bi));
usm=usedMegaToArabic(parseInt(mess.up)+parseInt(mess.ud))
};
if(mess.ud&&mess.ud!=""&&mess.ud!="0"){
usmd=usedMegaToArabic(parseInt(mess.ud)+parseInt(json.bytes.bo));
usm=usedMegaToArabic(parseInt(mess.up)+parseInt(mess.ud))
};
if(mess.uh&&mess.uh!=""&&mess.uh!="0"){
ush=hoursArabic(addtwotimes(json.time.ut,mess.uh));
};
if(usmu.indexOf('و')>0){usmu=usmu.split('و')[0]};
if(usmd.indexOf('و')>0){usmd=usmd.split('و')[0]};
};
getMonotoring(json);
}catch(e){};
statusEls.usedMega&&(statusEls.usedMega.innerText=usm);
statusEls.usedMegaUp&&(statusEls.usedMegaUp.innerText=usmu);
statusEls.usedMegaDown&&(statusEls.usedMegaDown.innerText=usmd);
statusEls.usedHours&&(statusEls.usedHours.innerText=ush);
statusEls.remHours&&(statusEls.remHours.innerText=hoursArabic(json.time.sto));
statusEls.remMega&&(statusEls.remMega.innerText=remMegaToArabic(json.bytes.rbt));
if(us&&us!=""){
var ms=json.mac||"";
var mspl='';if(ms.indexOf(':')>1){mspl=ms.split(':').join('');mspl.replace(/[A-Za-z]/g,function(a){a=a.toUpperCase();var p = parseInt(a,16);return p.toString();});};
var msco='1'.concat(mspl);
if(us==("T-".concat(ms))){
usernameV.innerHTML='<span style=\'color:green\'> تجربة مجانية';
profileA&&profileV&&(profileA.style.display='none');
setItemAll('_Lastuser',us);
setItemAll('_Lastpass','');
}else if(us==("S-".concat(ms))){
usernameV.innerHTML='<span style=\'color:green\'> سلفة'; 
profileA&&profileV&&(profileA.style.display='none');
setItemAll('_Lastuser',us);
setItemAll('_Lastpass','');
}else if(us==("C-".concat(ms))||us===msco){
usernameV.innerHTML ="<span style='color:green'> كرت مجاني من خدمة اجمع واربح";
setItemAll('_Lastuser',us);
setItemAll('_Lastpass','');
} else{
var l=us.length;
us="".concat("*".repeat(l<4?3:(l-4)),us.substring(0, 4));
usernameV.innerHTML=us;
}
usernameA.style.display='';
}}}  else{
showLoginPage();
try{clearInterval(setIntervalStatusQury);}catch(e){};
}}).catch(function(data){
clearInterval(setIntervalStatusQury)
})
}
function fillstorageSpeeds(a){
var json=a&&a!=null?a:hotspotData;
var ext=getStatusExtra(json);
var us=getLastUs(json);
if (ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){
saveSpeed('speed_change',ext['CN'],us);
fillSpeed2(ext['CN'],json)
} else{
setTimeout(function(){
    fillSpeed2(jsonConfig.login.speeds,json)    
}, 100);
}}
var isNewLoginStatusQury;var isNewLoginStatusQury2=true;var isNewLoginStatusQury3=true;
function startStatusQury(){
var statust=document.querySelectorAll('[data-statust]');statusEls={};statust&&statust.forEach(function(el){statusEls[el.getAttribute('data-statust')]=el;})
try{if(setIntervalStatusQury){clearInterval(setIntervalStatusQury);};if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)}}catch(e){};
getsHotspotStatus().then(function(data){
var json=data[0];var isLogin=data[1];
var ext=getStatusExtra(json);
var us=getLastUs(json);var spp={};
if (ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length){
    saveSpeed('speed_change',ext['CN'],us);
};
if(isLogin&&toBoolen(json.rad)&&isNewLoginStatusQury3&&isRadius(json)&&json.dom===""){
isNewLoginStatusQury3=false;
if(isSPD(null)){
changeSpeed(getSpeedIndex(getSpeedDefault('512K/1M'))||1,getSpeedDefault('512K/1M'),'dsd',0);
setTimeout(function(){showApp(null,null,'speeds');getAllSpeeds(json);try{if(setIntervalStatusQury){clearInterval(setIntervalStatusQury);};if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)}}catch(e){};}, 2100);
return setTimeout(function(){showApp(null,null,'speeds');}, 3200);
}}
try {onStatusStartFirst(us,typeof jsonConfig=="object"&&jsonConfig.network&&jsonConfig.network.name||"");} catch (e) {}
var neerLogin=json&&json.secs&&json.secs.ut&&parseInt(json.secs.ut)<=10;
if(neerLogin&&isNewLoginStatusQury2){
try{if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)}}catch(e){};
isNewLoginStatusQury=setTimeout(function(){var ts=((new Date()).getTime());getItemAll('newLin',ts).then(function(a){if(typeof a=="string"){a=parseInt(a)};if(typeof a!="number"||isNaN(a)){a=ts};if (a&&null!=a&&a<ts||ts===a){ts=(ts*1+100000);
setItemAll('newLin',ts).then(function (a) {
window.location.href='/index.html';
});}})},9000);
isNewLoginStatusQury2=false;
};
isNewLogin=false;
setTimeout(function(){
fillSpeed2(false,json);
}, 500);
setTimeout(function(){onStatusStart(json);}, 3000);
try{fillStatusDetails(json);}catch(e){console.log('fillStatusDetails',e)}
fillstorageSpeeds(json);
});
setIntervalStatusQury = setInterval(getStatusQury,5000);
setTimeout(getStatusQury, 100); 
getStatusQury();
if(jsonConfig.status&&jsonConfig.status.hidden&&jsonConfig.status.hidden.length){
    for(var i in jsonConfig.status.hidden){
        var el= statusEls[jsonConfig.status.hidden[i]];
        if(el){el.parentElement.style.display='none'}
    }
}
}
function showThisSpeeds(json){
if ((json&&json['SPN']&&json['SPN'].length)){
var upd=(json['D']=="1"||json['D']==1);
if(upd){upd=1;osamaUpdateChecked=1} else{osamaUpdateChecked=0;upd=0};
if(json['SPN']&&json['SPN'].length!=0){
var selectSpeeds=document.getElementById('speedn')||{};
var speeds=json['SPN'];
var speedsV=json['SPD'];
selectSpeeds.innerHTML='';
var fundDef=false;
var spx=parseInt(json['X']);
if(speedsV[spx]){}else{spx=parseInt(json['SD'])};
if(spx==osamaSpeedIndex || typeof osamaSpeedIndex!="number"){}else{spx=osamaSpeedIndex};
if(speedsV[spx]){}else{spx=parseInt(json['SD'])};
if(typeof hotspotData=="object"&&isRadius(hotspotData)){
if(hotspotData.dom&&hotspotData.dom!=''){
var dom=hotspotData.dom;
if (dom.indexOf('OFF')>-1){
dom=dom.split('_')[0];
upd=1;
osamaUpdateChecked=1;
}else{
upd=0;
osamaUpdateChecked=0;
};
if(speedsV.indexOf(dom)>-1){
spx=speedsV.indexOf(dom)*1;
osamaSpeedIndex=spx*1;
osamaSpeedValue=dom
}}};
changeUpdateData(upd);
for(var key in speeds){
var na=speeds[key];
var id='value'.concat('-',key);
var val=speedsV[key];
var df=(spx==key);
if(df){fundDef=true;osamaSpeedIndex=key*1;osamaSpeedValue=val;osamaSpeedName=na}
newInputRadio(id,key,val,na,df,eventSelectSpeedRadio,selectSpeeds);
}
if(fundDef){
setItemAll('spv',osamaSpeedValue);
setItemAll('spi',osamaSpeedIndex);
setItemAll('spn',osamaSpeedName);
} else{
getItemAll('spv',osamaSpeedValue).then(function(a){
for(var i in speedForm.speednv){var el=speedForm.speednv[i];if(el.value==a){fond=true;el.checked=true;speedForm.speednv.value=a;osamaSpeedValue=a;osamaSpeedName=el.getAttribute('data-speedn');osamaSpeedIndex= parseInt(el.getAttribute('data-speedi'))*1}}});    
}} else{
if('file:'!==window.location.protocol){
setTimeout(showStatusPage,800,'speeds'); 
}}} else{
if('file:'!==window.location.protocol){
setTimeout(showStatusPage,800,'speeds'); 
}}}
var getMonotoringData={"m":0.0,"t":0.0,"l":[0.0,0.0,0.0],"r":0.0,'TS':0.0};
var getMonotoringMSG=false;
var getMonotorMSG=false;
var getMonotoringUSERS={};
var getMonotoringTS=getTimeNow(0);
function getMonotoring(data){
var json=data&&data!=null?data:hotspotData;
var usr=json.usr;
var up=parseFloat(json.bytes.bi);if(isNaN(up)){up=1.0}
var bo=parseFloat(json.bytes.bo);if(isNaN(bo)){bo=1.0}
if(up<1024){up=1025.0};if(bo<1024){bo=1025.0}
var mg=parseFloat(up)+parseFloat(bo);
if (json.bytes.rbt&&json.bytes.rbt!='0'&&json.bytes.rbt!=''){if(getMonotoringUSERS[usr]){getMonotoringUSERS[usr]['M']=json.bytes.rbt;getMonotoringUSERS[usr]['T']=json.secs.sto;}else{getMonotoringUSERS[usr]={"MX":json.bytes.rbt,"ST":json.secs.sto}}}
mg=mg/80.0;
if(mg<2.0){mg=2.0};
mg=parseFloat(mg);
mg=mg.toFixed(1);
var ut=parseFloat(json.secs.ut)*1.0;
if(ut<1){ut=1}
if (!getMonotoringMSG&&json.bytes.rbt&&json.bytes.rbt!='0'&&json.bytes.rbt!=''&&json.bytes.lbt&&json.bytes.lbt!='0'&&json.bytes.lbt!=''){
var my=((parseFloat(up)*1.01)+(parseFloat(bo)*1.01))*1.01;
var mx=parseFloat(json.bytes.lbt)*1.01;
if(mx>(1024.1*1024.1*1024.1*3.1)){mx=(1024.1*1024.1*1024.1*3.1);}
var mr=(my/mx);
var mo=(mg/ut);
if ((mg > (1024*30) && ut >20 && (my>(1024.1*1024.1*10.1)) && (mr>0.08) && mo>4000.1)||(my > (1024.1*1024.1*80.1) && ut <520)){
getMonotoringMSG=true;
my=((parseFloat(up)+parseFloat(bo)) / (1024.01*1024.01)).toFixed(1);
var utz=(ut / 60.001).toFixed(0);if(utz<1){utz=1};
var ms=" اكثر من ".concat(my," ميجا خلال اقل من ",utz,' دقيقة ');
document.querySelector("[data-speed-value]").innerHTML=''.concat(document.querySelector("[data-speed-value]").innerHTML,'<p style="color:red;font-size:9px">تحذير انت تستهلك الرصيد بشكل كبير جدا </p>');
if(!getMonotorMSG){showErrorPopup(' تحذير انت تستهلك الرصيد بشكل كبير جدا <p>'.concat(ms));}
getMonotorMSG=true;
}    
}
var lsmg=getMonotoringData['m'];
var lsut=getMonotoringData['t'];
var lts=getTimeNow(0)-getMonotoringTS;
var ltss=parseFloat(lts)/1000.0;
ltss=ltss.toFixed(1);
var ts=parseFloat(ut*1.0-lsut*1.0);
if(ts<1.0){ts=1.0};
ts=(ts+ltss)/2;
if(ts>7){ts=ltss}
getMonotoringTS=getTimeNow(0);
var thisSp=1.0;
thisSp=parseFloat(parseFloat(parseFloat(mg) - parseFloat(lsmg))/ ts).toFixed(2);
var lsl=getMonotoringData['r'];
getMonotoringData['m']=mg;
getMonotoringData['t']=ut;
getMonotoringData['l1']=thisSp;
getMonotoringData['l2']=getMonotoringData['l1']||thisSp;
getMonotoringData['l3']=getMonotoringData['l2']||thisSp;
getMonotoringData['l'].push(thisSp);
if (getMonotoringData['l'].length>=20){getMonotoringData['l']=getMonotoringData['l'].slice(1,20);}
var sp0=thisSp*2
var sp1=parseFloat(getMonotoringData['l2']*2);
var sp2=parseFloat(getMonotoringData['l3']*1);
thisSp=parseFloat(sp0+sp1+sp2) /5;
thisSp=thisSp.toFixed(1);
if(thisSp<0){thisSp=thisSp*-1.0}
getMonotoringData['r']=thisSp;
var smb='Kbps',smr='Kbps';
var rt=((lsl - thisSp)/2.0);
if(rt<0){rt=rt*-1.0};
var col='green';
if(thisSp>5048.0||getMonotoringMSG){col='red';};
if(thisSp>1048.0){smb='Mbps';thisSp=thisSp / 1024.0;thisSp=thisSp.toFixed(1)};
if(thisSp>1048.0){smb='Gbps';thisSp=thisSp / 1024.0;thisSp=thisSp.toFixed(1)};
if(rt>1048){smr='Mbps';rt=(rt/1024).toFixed(1)};
if(rt>1048){smr='Gbps';rt=(rt/1024).toFixed(1)};
document.querySelector('[data-speed-name]').innerText="  ".concat(thisSp,smb,"  ");
document.querySelector('[data-speed-name]').style.color=col;
document.querySelector('[data-speed-name]').style.padding='3px';
document.querySelector('[data-speed-name]').style.fontSize='13px';
document.querySelector('[data-speed-name]').style.marginLeft='-30px';
return [thisSp+smb,rt+smr];
}
function getAllSpeeds(data){
var selectSpeeds=document.getElementById('speedn');
selectSpeeds.innerHTML='';
var us=getLastUs(data);
var speedsV={};
if(isSPD(null)){speedsV=jsonConfig.login.speeds};
sLoading(0);sClows(800);
if(us&&us!=''&&us!='_LAST'&&typeof speed_change == "object"&&speed_change[us]&&isSPD(speed_change[us])&&isSPD(null)){speedsV=speed_change[us]};
try{if(setIntervalStatusQury){clearInterval(setIntervalStatusQury);};if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)}}catch(e){};
var ext=getStatusExtra(data||hotspotData);
if (ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length&&isSPD(null)){speedsV=ext['CN']};
return serverRequest({'FN':'GETSPS'},speedsV).then(function(ret){
if(ret){
var json=ret[0];
var status=ret[1];
if (status == 'ok'&&json&&json['SPD']&&json['SPD'].length>0){
showThisSpeeds(json);
showApp(null,null,'speeds');
} else{
setTimeout(showStatusPage,800,'speeds'); 
}
saveSpeed('speed_check',json,us)
} else{
setTimeout(showStatusPage,800,'speeds'); 
}})
};
function dellThisUser(us){return getItemAll('last_users',false).then(function(v){var data=[];for(var i in v){if("object"==typeof v[i] && v[i]!==null){if(v[i]['u']&&v[i]['u']==us&&v[i]['u']!=''){} else{data.push(v[i]);}}};setItemAll('last_users',data);return data})}
function saveThisUser(v){return getItemAll('last_users',false).then(function(data){var found=false;if (typeof v == "object"&&v!=null){var us=v['u'];if (typeof data != "object"||data==null){data=[{u:'',p:'',d:'',r:'',i:'',z:{}}]};for(var i in data){if("object"==typeof data[i] && data[i]!==null){var usv =data[i]['u'];if(usv==us&&usv!=''){found=true;for(var x in v){data[i][x]=v[x]};setItemAll('last_users',data);return data}}};try{if(!found){if(typeof data==="object"){for(var i in data){if("object"==typeof data[i] && data[i]!==null && typeof found!=="number"){var usv =data[i]['u'];if(usv==''){found=i}}};if(typeof found==="number"){data[found]=v} else{data.push(v)};setItemAll('last_users',data)}};}catch(e){}};return data;})}
function getThisUser(us){return getItemAll('last_users',false).then(function(data){if (typeof data != "object"||data==null){data=[{u:'',p:'',d:'',r:'',i:'',z:{}}]};for(var i in data){if("object"==typeof data[i] && data[i]!==null){var usv =data[i]['u'];if(usv==us&&usv!=''){return [data[i],data]}}};return [false,data]})}
function getThisUserSPD(us){return getItemAll('speed_change',false).then(function(data){if (typeof data != "object"||data==null){return false};for(var i in data){if("object"==typeof data[i] && data[i]!==null && i==us){return data[i]}};return false})}
function checkNewPoints(us,ps,ds,upd,rad) {
var dom=decodeURIComponent(ds||'');us=decodeURIComponent(us);
if(us&&us.indexOf('@')>-1){dom=us.split('@')[1];us=us.split('@')[0];};
if(dom&&dom.includes('OFF')){dom=dom.split('_')[0];upd=1};
if (us&&us.includes&&us.includes(':')&&us.includes(':')){} else{
getItemAll('last_users',null).then(function(data){
var dz={ft:getTimeNow(0),lt:getTimeNow(0)};
if (typeof data != "object"||data==null){data=[{u:'',p:'',d:'',r:'',i:'',z:dz},{u:'',p:'',d:'',r:'',i:'',z:dz},{u:'',p:'',d:'',r:'',i:'',z:dz},{u:'',p:'',d:'',r:'',i:'',z:dz},{u:'',p:'',d:'',r:'',i:'',z:dz}]}
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
var fond=false;
for(var x in data){if(data[x]&&data[x]['u']&&data[x]['u']==us){fond=true;} else{}};
if (!fond){
var usv={u:us,p:ps,d:ds,i:upd,z:dz,r:rad,"E":false};
var v=[];
v.push(usv);
for(var x in data){if(x<4&&data[x]&&data[x]['u']&&data[x]['u']==us){} else{v.push(data[x]);}};
isNewUser=us;
v=v.slice(0,15);
setItemAll('last_users',v);
data=v;
last_users=data;
} else{
if(data){
var usv={u:us,p:ps,d:ds,i:upd,z:dz,r:rad,"E":false};
for(var x in data){if(data[x]&&data[x]['u']&&data[x]['u']==us){usv=data[x];usv['d']=ds;usv['E']=false;usv['i']=upd;usv['p']=ps;usv['r']=rad;if(usv['z']){usv['z']['lt']=getTimeNow(0)}} else{}};  
var v=[];
v.push(usv);
for(var x in data){if(data[x]&&data[x]['u']&&data[x]['u']==us){} else{if(x<15){v.push(data[x]);}}};
data=v.slice(0,15);
};
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});
data.push({u:'',p:'',d:'',r:'',i:'',z:dz});    
data=data.slice(0,15);
setItemAll('last_users',data);
last_users=data;
isNewUser=false;
}
setLastUsersSelect(data);
});
}
setItemAll('_Lastuser',us);
setItemAll('_Lastpass',ps);
setItemAll('_Lastdom',ds);
setItemAll('_Lastrad',rad);
}
function getByLastUserData(){
var dataSPD=null;
if(isSPD(null)){dataSPD=jsonConfig.login.speeds;}
return getItemAll('_Lastuser',"").then(function(dataU){
var dataD='';try {dataU=decodeURIComponent(dataU);if (dataU&&dataU.indexOf('@')>-1){dataD=dataU.split('@')[1];dataU=dataU.split('@')[0]};}catch(e){};
try {
return getItemAll('_Lastpass',"").then(function(dataP){
return getItemAll('_Lastdom',false).then(function(dataDOM){
return getItemAll('_Lastrad',false).then(function(rad){
if(dataU&&dataU!=null&&dataU!=''){
var dataOBJ={"username":dataU,"password":(dataP||"")};
return getThisUserSPD(dataU).then(function(sret){
if(dataD===""&&dataDOM){dataD=dataDOM};
if(sret&&isSPD(null)){dataSPD=sret};
if(toBoolen(rad)){dataOBJ['domain']=dataD;};
return [dataOBJ,dataSPD,toBoolen(rad)];
})};
return [null,null];
})
})
})
} catch (e) {};
return [null,null];
});
}
function isKickFoundUser(e){
try {
var a=(e||{});
var ers=a.ers||"";
var ero=a.ero||"";
var ert=a.ert||"";
var er=''.concat(ero,ert,ers);
er=er.toLowerCase();
ert=ert.toLowerCase();
if(ert.includes("user-session-limit")||ert.includes("radius-reply")&&((er.includes('session')&&!er.includes('time'))||er.includes('already+logged+in')||er.includes('already logged in')||(er.includes('جهاز')&&!er.includes('mac')&&er.includes('خر')))){
if(er.includes("this mac") || er.includes('wrong-mac-username')|| er.includes('invalid-mac')){return false}
return true;
}} catch (e) {}
return false;    
}
function isTrafficOrTimeOrDayesEnds(e){
try {
var a=(e||{});
var ers=a.ers||"";
var ero=a.ero||"";
var ert=a.ert||"";
var er=''.concat(ero,ert,ers);
er=er.toLowerCase();
ert=ert.toLowerCase();
if((ert.includes("traffic-limit")||ert.includes("invalid-mac")||ert.includes("wrong-mac-username")||ert.includes("uptime-limit")||ert.includes("uptime-limit"))||(ert.includes("radius-reply")&&(er.includes('traffic')||er.includes('validity')||er.includes('quota')||er.includes('time')||er.includes('profile')||er.includes('صلاحي')))){
return true;
}} catch (e) {}
return false;    
}
function isTrafficEnds(e){
try {
var a=(e||{});
var ers=a.ers||"";
var ero=a.ero||"";
var ert=a.ert||"";
var er=''.concat(ero,ert,ers);
er=er.toLowerCase();
ert=ert.toLowerCase();
if((ert.includes("traffic-limit"))||(ert.includes("radius-reply")&&(er.includes('raffic')||er.includes('quota')))){
return true;
}} catch (e) {}
return false;    
}    
function isTimeEnds(e){
try {
var a=(e||{});
var ers=a.ers||"";
var ero=a.ero||"";
var ert=a.ert||"";
var er=''.concat(ero,ert,ers);
er=er.toLowerCase();
ert=ert.toLowerCase();
if((ert.includes("uptime-limit"))||(ert.includes("radius-reply")&&(er.includes('time')))){
return true;
}} catch (e) {}
return false;    
}    
function isDayesEnds(e){
try {
var a=(e||{});
var ers=a.ers||"";
var ero=a.ero||"";
var ert=a.ert||"";
var er=''.concat(ero,ert,ers);
er=er.toLowerCase();
ert=ert.toLowerCase();
if((ert.includes("invalid-mac")||ert.includes("wrong-mac-username")||ert.includes("invalid-username"))||(ert.includes("radius-reply")&&(er.includes('sername doesn')||(er.includes('not')&&er.includes('found'))||er.includes('validity')||er.includes('profile')||er.includes('صلاحي')))){
return true;
}} catch (e) {}
return false;    
}
function changeUpdateData(upd){
if (upd&&(upd==1||upd=='1'||upd==true)){
updates2&&(updates2.checked=true);
updates&&(updates.checked=true);
osamaUpdateChecked=1;
} else {
updates&&(updates.checked=false);
updates2&&(updates2.checked=false);
osamaUpdateChecked=0;
} 
setItemAll('upd',osamaUpdateChecked);
}
function eventLoginSelectSpeedRadio2(e) {
document.getElementById("dialog-close").checked=true;
var selectC=document.querySelectorAll("input[name=speednvd]");for(var i in selectC){var el=selectC[i];if(el.checked){osamaSpeedName= el.getAttribute('data-speedn');osamaSpeedValue= el.getAttribute('data-speedv');osamaSpeedIndex=  parseInt(el.getAttribute('data-speedi'))*1;var spx=parseInt(osamaSpeedIndex)*1 + 1;try {document.getElementById('speed_select').options.selectedIndex=spx;} catch (e) {}}}
var el=e.target;
osamaSpeedName= el.getAttribute('data-speedn');
osamaSpeedValue= el.getAttribute('data-speedv');
osamaSpeedIndex= parseInt(el.getAttribute('data-speedi'))*1;
setItemAll('spv',osamaSpeedValue);
setItemAll('spn',osamaSpeedName);
setItemAll('spi',osamaSpeedIndex);
setItemAll('spu',(osamaSpeedUser=getLastUs(hotspotData)||osamaSpeedUser,osamaSpeedUser));
setTimeout(function(){
loginFormOnSubmitDialog=false;
loginFormOnSubmitDialog22=false;
submitDoneDoLogin=false;
if(showDialogSpeedsSUMBIEDE){
sLoading(0);
sClows(1000);
doLoginOnFormOnSubmit(document.getElementById('usern').value,document.getElementById('passw').value,osamaSpeedValue,osamaUpdateChecked);
}}, 500);
for(var i in selectC){var el=selectC[i];if(el.checked){osamaSpeedName= el.getAttribute('data-speedn');osamaSpeedValue= el.getAttribute('data-speedv');osamaSpeedIndex=  parseInt(el.getAttribute('data-speedi'))*1;var spx=parseInt(osamaSpeedIndex)*1 + 1;try {document.getElementById('speed_select').options.selectedIndex=spx*1;} catch (e) {}}}
e&&e.preventDefault&&e.preventDefault();
return false;
}

function eventLoginSelectSpeedRadio4(issubm) {
document.getElementById("dialog-close").checked=true;
var selectC=document.querySelectorAll("input[name=speednvd]");for(var i in selectC){var el=selectC[i];if(el.checked){osamaSpeedName= el.getAttribute('data-speedn');osamaSpeedValue= el.getAttribute('data-speedv');osamaSpeedIndex=  parseInt(el.getAttribute('data-speedi'))*1;var spx=parseInt(osamaSpeedIndex)*1 + 1;try {document.getElementById('speed_select').options.selectedIndex=spx*1;} catch (e) {}}}
setTimeout(function(){
for(var i in selectC){
var el=selectC[i];
if(el.checked){
osamaSpeedName= el.getAttribute('data-speedn');
osamaSpeedValue= el.getAttribute('data-speedv');
osamaSpeedIndex=  parseInt(el.getAttribute('data-speedi'))*1;
setItemAll('spv',osamaSpeedValue);
setItemAll('spn',osamaSpeedName);
setItemAll('spi',osamaSpeedIndex);
setItemAll('spu',document.getElementById('usern').value);
var spx=parseInt(osamaSpeedIndex)*1 + 1;
try {document.getElementById('speed_select').options.selectedIndex=spx*1 ;} catch (e) {}
loginFormOnSubmitDialog=false;
loginFormOnSubmitDialog22=false;
setTimeout(function(){
if(issubm){
sLoading(0);
sClows(1000);
showDialogSpeedsSUMBIEDE=false;
doLoginOnFormOnSubmit(document.getElementById('usern').value,document.getElementById('passw').value,osamaSpeedValue,osamaUpdateChecked);
}}, 50);
}};
}, 100);
}
function newLoginInputRadio(a,b,z,f,c,d,vvv){
var ell=document.createElement('label');
ell.setAttribute('for',a);
ell.innerHTML=z;
var el=document.createElement('input');
el.name='speednvd';
el.value=b;
el.id=a;
el.type='radio';
if (f){el.setAttribute('checked','checked');}
el.setAttribute('data-speedn',z);
el.setAttribute('data-speedv',vvv);
el.setAttribute('data-speedi',b);
ell.className='bot';
el.addEventListener('click',c);
d.appendChild(el);
d.appendChild(ell);
return d;
}
var showDialogSpeedsSUMBIEDE=false;
var showDialogSpeedsValues={};
function showDialogSpeeds(insubm){
try{
if(isSPD(null)){
document.getElementById('dialog-app').style.opacity=1;
var selectSpeeds=document.querySelector(".dialog-cont");
var json=showDialogSpeedsValues;
if (!isSPD(json)){json=jsonConfig.login.speeds};
if (isSPD(json)){
var upd=(json['D']=="1"||json['D']==1);
var ische='';
if(upd){ische='checked';osamaUpdateChecked=1} else{if(osamaUpdateChecked==1||osamaUpdateChecked=='1'){ische='checked';upd=1;}}
if(json['SPD']&&json['SPD'].length!=0){
selectSpeeds.innerHTML='<p class="app-title" data-i18n="subandresub">إختيار السرعة </p> <div class="bot" style="width: 100%;margin-left: 0;"> <div style="display: flex;font-size: 0.8em;padding-right:5px"> تشغيل تحديثات جوجل بلاي <div class="toggles" style="margin-top:0;width:30px" > <input type="checkbox"  name="updates" '.concat(ische,' id="updates3" onchange="osamaUpdateChecked=this.checked?1:0;document.getElementById(\'updates2\').checked=osamaUpdateChecked;document.getElementById(\'updates\').checked=osamaUpdateChecked"  class="ios-toggle"> <label for="updates3" style="font-size: 0.8em;" class="checkbox-label" data-on="التحديثات وقفة" data-off="التحديثات تعمل"></label> </div> </div></div>');
var speeds=json['SPN'];
var speedsV=json['SPD'];
var fundDef=false;
var spx=parseInt(json['X']);
if(speedsV[spx]){}else{spx=parseInt(json['SD'])};
if(spx==osamaSpeedIndex || typeof osamaSpeedIndex!="number"){}else{spx=osamaSpeedIndex};
if(speedsV[spx]){}else{spx=parseInt(json['SD'])};
for(var key in speeds){
var na=speeds[key];
var id='value'.concat('-',key);
var val=speedsV[key];
var df=(spx==key);
if(df){fundDef=true;osamaSpeedIndex=key*1;osamaSpeedValue=val;osamaSpeedName=na}
newLoginInputRadio(id,key,na,df,eventLoginSelectSpeedRadio2,selectSpeeds,val);
};
if(insubm){insubm='true';showDialogSpeedsSUMBIEDE=true} else{insubm='false';showDialogSpeedsSUMBIEDE=false}
var sub='<button onclick="eventLoginSelectSpeedRadio4('.concat(insubm,')" class="btn login-btn"  style="width: 100%">إختيار</button>');
var dv=document.createElement('div');
dv.innerHTML=sub;
selectSpeeds.appendChild(dv);
document.getElementById("dialog-close").checked=false;
if(fundDef){
setItemAll('spv',osamaSpeedValue);
setItemAll('spi',osamaSpeedIndex);
setItemAll('spn',osamaSpeedName);
setItemAll('spu',(osamaSpeedUser=getLastUs(hotspotData)||osamaSpeedUser,osamaSpeedUser));
} else{
getItemAll('spv',osamaSpeedValue).then(function(a){
var selectC=document.querySelectorAll("input[name=speednvd]");
for(var i in selectC){var el=selectC[i];if(el.value==a){fond=true;el.checked=true;el.value=a;osamaSpeedValue=a;osamaSpeedName=el.getAttribute('data-speedn');osamaSpeedIndex= parseInt(el.getAttribute('data-speedi'))*1}}});    
}} else{
document.getElementById('speed_select_dev').style.opacity=0;
document.getElementById('speed_select_dev').style.position='absolute';    
document.getElementById('speed_select').removeAttribute('required')
insubm&&doLoginOnFormOnSubmit(document.getElementById('usern').value,document.getElementById('passw').value,osamaSpeedValue,0)
}}else{
document.getElementById('speed_select_dev').style.opacity=0;
document.getElementById('speed_select_dev').style.position='absolute';
document.getElementById('speed_select').removeAttribute('required')
insubm&&doLoginOnFormOnSubmit(document.getElementById('usern').value,document.getElementById('passw').value,osamaSpeedValue,0)
}} else{
document.getElementById('speed_select_dev').style.opacity=0;
document.getElementById('speed_select_dev').style.position='absolute';
document.getElementById('speed_select').removeAttribute('required')
insubm&&doLoginOnFormOnSubmit(document.getElementById('usern').value,document.getElementById('passw').value,osamaSpeedValue,0)
}}catch(e){
insubm&&doLoginOnFormOnSubmit(document.getElementById('usern').value,document.getElementById('passw').value,osamaSpeedValue,0)
}}
function loginByLastUserssUBMIT(us,ps,dm,upd,ur1,ur2){
doNewLogin(ur1).then(function(json1){
var islog1=json1&&json1.lin&&json1.lin==="yes";
if(islog1){
try{setItemAll('block-count',1);} catch(e){};
try{removeItemAll('block-count')} catch(e){};
showStatusPage();
submitDoneDoLogin=false;
try {saveNewLoginSpeed(us,ps,dm,upd);} catch (e) {}    
} else{
loginForm.username.value='';
loginForm.password.value='';
if(isKickFoundUser(json1)){
return showKickUser(us,ps,dm,upd);
} else {
setTimeout(function(){
if(ur2!=ur1||!isTrafficOrTimeOrDayesEnds(json1)){
doNewLogin(ur2).then(function(json2){
var islog2=json2&&json2.lin&&json2.lin==="yes";
if(islog2){
showStatusPage();
submitDoneDoLogin=false;
try {saveNewLoginSpeed(us,ps,dm,upd);} catch (e) {}    
} else{
if(isKickFoundUser(json2)){
return showKickUser(us,ps,dm,upd);
} else{
}}})} else{
}},300)
}}});
}
var loginByLastUsersTS=true;
function loginByLastUsers(){
setTimeout(function(){loginByLastUsersTS=true}, 2000);
if(loginByLastUsersTS){
loginByLastUsersTS=false;
getItemAll('_Lastuser',"").then(function(dataU){
    getItemAll('_Lastpass',"").then(function(dataP){
        getItemAll('spv',false).then(function(dataD){
            getItemAll('upd',0).then(function(upd){
                if(dataU&&dataU!=""){
                if(dataD&&dataD.includes('OFF')){upd=1;};
                var ur1='/json/login?username='.concat(dataU);
                var ur2='/json/login?username='.concat(dataU);
                if(dataP&&dataP!=""){ur1=ur1.concat('&password=',dataP);ur2=ur2.concat('&password=',dataP)};
                if(dataD&&dataD!=""){ur1=ur1.concat('&domain=',dataD);if(upd&&ur1.indexOf('OFF')==-1&&upd==''){ur1=ur1.concat('_OFF')}};
                try{if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login&&jsonConfig.login.dst&&jsonConfig.login.dst!=''){ur1=ur1.concat('&dst=',jsonConfig.login.dst);ur2=ur2.concat('&dst=',jsonConfig.login.dst)}}catch(e){};
                loginByLastUserssUBMIT(dataU,dataP,dataD,upd,ur1,ur2);
            }
            })
        })
    })
})
}
}
function isSPD(a){
if (typeof a=="object"&&a!=null){return (a&&a['SPD']&&a['SPD'].length>0)};
if (typeof jsonConfig == "object"&&jsonConfig.login&&jsonConfig.login.speeds){a=jsonConfig.login.speeds;return (a&&a['SPD']&&a['SPD'].length>0);};
return false;
}
function saveSpeed(n,v,us) {if(n=='speed_change'){speed_change[us]=v;};if(n=='speed_check'){speed_check[us]=v;};return getItemAll(n,{}).then(function(a){if("object"!=typeof a&&a!=null){a={}};var o={},j=0;for(var i in a){if(a[i]&&a[i]['_T']&&getTimeNow(0)<a[i]['_T']&&j<10){o[i]=a[i];j=j*1+1}};o[us]=v||{};o[us]['_T']=getTimeNow(7*24*60*60*1000);speed_last=v;setItemAll(n,o);return o;})}
function changeSpeed(rateIndex,rateValue,rateName,upd){
var us =getLastUs(hotspotData);
if(us&&us!='_LAST'&&us!=''){us=osamaSpeedUser}
try{
showApp(null,null,'status');
setItemAll('spv',rateValue);setItemAll('spn',rateName);setItemAll('spi',rateIndex);setItemAll('upd',upd);setItemAll('spu',us);
setTimeout(showStatusPage,2300);sLoading(100);sClows(3000);
}catch(e){}
try{if(setIntervalStatusQury){clearInterval(setIntervalStatusQury);};if (isNewLoginStatusQury){clearTimeout(isNewLoginStatusQury)}}catch(e){}
var spx=parseInt(rateIndex)*1;var spd =rateValue;var spn =rateName;var updStr= spn;
if(upd){upd=1;updStr=''.concat(updStr,"<p style='color:red;font-size: 10px;'> (التحديثات موقفة) </p>")} else{upd=0};
var speedsV={};
if(isSPD(null)){speedsV=jsonConfig.login.speeds};
var ext=getStatusExtra(hotspotData);
if(us&&us!=''&&us!='_LAST'&&typeof speed_change == "object"&&speed_change[us]&&isSPD(speed_change[us])&&isSPD(null)){speedsV=speed_change[us]};
if(ext&&ext['CN']&&ext['CN']['SPD']&&ext['CN']['SPD'].length&&isSPD(null)){speedsV=ext['CN']};
return serverRequest({'FN':'CHSP',"X":spx,"D":upd,"S":spd},speedsV).then(function(ret){if(ret&&ret[0]){
ret[0]['X']=spx;ret[0]['D']=upd;
if(us&&us!='_LAST'&&us!=''){saveThisUser({u:us,d:spd,i:upd});};
if(isSPD(ret[0])&&ret[1]=='ok'){
try {sesp.options.selectedIndex=(spx*1 + 1);} catch (e) {}
saveSpeed('speed_change',ret[0],us);showErrorPopup("<span style='color:green'> تم اختيار  ".concat(updStr,'</span>'));} else{if(ret[1]!=='ok'){showErrorPopup("<span style='color:red'> لم يتم تغيير السرعة ".concat("<p>قم بتسجيل الدخول من جديد</p>",'</span>'));};showStatusPage(null);}}});
}
function doKickUser(){
sLoading(550);
serverRequest({ "FN": 'KICK'},{}).then(function (ret2) {
if(ret2){}else{ret2=[false,false]}
var json2=ret2[0];
if (json2&&json2['KICK']&&(json2['KICK']==1||json2['KICK']=="1")){
setTimeout((function(){
errElem.innerHTML='<h3>جاري اعادة تسجيل الدخول</h3>';
setTimeout((function(){errCont&&errCont.classList.add("zoom")}),150);
setTimeout((function(){errCont&&errCont.classList.add("active")}),50);
sLoading(0);sClows(2000);
}),150);
var dataU=whenKick['u']||"";var dataP=whenKick['p']||"";
if(typeof whenKick['d']=="undefined"||whenKick['d']==''){setTimeout(function(){submitDoneDoLogin=false;showDialogSpeeds(true);},1000);}else{
setTimeout(function(){doLoginOnForm(dataU,dataP,whenKick['d'],whenKick['z'])},400)
}
if(!dataU.includes(':')){loginForm.username.value=dataU;loginForm.password.value=dataP;}
loginFormOnSubmitDialog22=false;loginFormOnSubmitDialog=false;
} else{
errElem.innerHTML='<h3>اعد المحاولة لاحقا</h3>';
loginForm.username.value='';
loginForm.password.value='';
sClows(5000);
}})
}
function showKickUser(us,ps,dm,upd){
whenKick={u:us,p:ps,d:dm,z:(toBoolen(upd)?1:0)};
setTimeout((function(){errCont&&errCont.classList.add("zoom")}),150);
setTimeout((function(){errCont&&errCont.classList.add("active")}),50);
errElem.innerHTML+='<br /><br /><div><h3>هل تريد استخدام الكرت في هذا الجهاز ؟</h3><button type="button" class="btn" style="display: inline-block;width:70px;margin-left:15px" onclick="doKickUser()">نعم </button><button type="button" class="btn" style="display: inline-block;width:70px;margin-left:15px" onclick="hideErrorPopup()">لا</button></div>';
}
function isBlockEd(us,ps){
getItemAll('block-count',1).then(function(na){
if(na==null){na=0};
na=parseInt(na||'1');
if(isNaN(na)){na=0} else{na=na*1;};
var message="<div class='err-warn'><br /><br /><h4>تحذير !! عدد محاولاتك الخاطئة اصبح {{na}} محاولاتك</h4><h4>اذا تجاوزت العدد المسموح للمحاولات {{count}} سيتم حظرك لمدة {{time}} دقائق</h4></div>";
var conf=jsonConfig&&jsonConfig.block||{block:1,time:3,count:15,warn:10,message:message }
conf.message=conf.message||message;
if(conf&&conf.block&&(na||na==0)){
if(na>conf.count){
var t=conf.time||3;
removeItemAll('block-count').then(function(a){setItemAll('block-count',1).then(function(a){var ur1='/json/login?username=BLOCKED';doNewLogin(ur1).then(function(a){window.location.href='/status?var='.concat(t,'&target=block');});});
});
}else if(conf.warn&&na>conf.warn) {
var n=(na*1+1);
setItemAll('block-count',n);
setTimeout(function(){
conf['na']=na;
errElem.innerHTML+= fillMustache(conf.message,conf);
setTimeout(function(){document.getElementById("err-cot").addEventListener("click",hideErrorPopup);}, 3000);
}, 2000);
setTimeout(function(){document.getElementById("err-cot").addEventListener("click",hideErrorPopup);}, 5000);
try{document.getElementById("err-cot").removeEventListener("click",hideErrorPopup)}catch(e){};
}  else{var n=(na*1+1);setItemAll('block-count',n);}}});
}
function isRadius(a){
var b;if(typeof a== "undefined"||a==null){a=hotspotData};
if(typeof a== "string"&&(a=='yes'||a=='true')){return 1};
if(typeof a== "string"&&(a=='no'||a=='false'||a=='')){return 0};
if(typeof a== "object"){if(a==null||typeof a.rad== "undefined"){return -1;};b=a.rad;};
if(b){if(typeof b== "string"&&(b=='yes'||b=='true')){return 1};if(typeof b== "string"&&(b=='no'||b=='false'||b=='')){return 0};};
return -1;
}
function serverRequest(a,speedsAR){
return new Promise(function(res,reg){
var fn=a['FN'];
if(fn=="GETSPS"){
if(typeof osamaSpeedIndex == "number"){speedsAR['X']=osamaSpeedIndex;};if(typeof osamaUpdateChecked == "number"){speedsAR['D']=osamaUpdateChecked;};return res([speedsAR,'ok']);
} else if(fn=="CHSP"){
var upd=a['D'];
var spx=a['X'];
var spd=a['S'];
var dm=spd;
var updport=8;
var ourl="/json/logout?erase-cookie=on";
if(upd&&upd!='0'&&dm&&dm.indexOf("OFF")==-1){upd=1;}else{upd=0}
if(upd){updport=updport*1+1};
if(upd){if(dm.indexOf('OFF')==-1){dm=''.concat(spd,'_OFF');}}
var spurl="".concat(window.location.protocol,"//",window.location.hostname,":648",updport,spx,'/status');
try{xmlFetch(spurl).then(function(r){}).catch(console.log);} catch(e){};
getsHotspotStatus().then(function(data){
var us=getLastUs(data[0]);
var isRad=isRadius(data[0]);
getPasswordSaved(us).then(function(ps){
if(ps==null){return res([speedsAR,'no']);};
doNewLogin(ourl).then(function(resss){
setTimeout(function(){getsHotspotStatus().then(function(zc){doLoginOnForm(us,ps,dm,upd);})},170);
speedsAR["X"]=spx;
speedsAR["D"]=upd;
setTimeout(function(){return res([speedsAR,'ok']);},150);
});
});
}); 
try{setIntervalStatusQury&&clearInterval(setIntervalStatusQury);}catch(e){};
} else if(fn=="KICK"){
doNewLogin("/json/login?username=KICKUSER").then(function(ss){
if(ss&&ss.lin&&ss.lin==='yes'){
setTimeout(function(){
doNewLogin("/json/logout?erase-cookie=on").then(function(res2){
return res([{"KICK":1},'ok']);
})
}, 1000);
}
else setTimeout(function(){
return res([{"KICK":0},'ok']);
},2000)
});
}else
return res([speedsAR,'ok']);
})
}
function doNewLogin(ur){
if(ur.indexOf('domain=')>-1){
	var dm =ur.split('domain=')[1]
	dm="".concat(dm,'& &');
	dm=dm.split('&')[0].replace(' ','');
	var dm0="".concat(dm);
	if(dm0.length>1) {
	if(hotspotData&&hotspotData['locn'] && hotspotData['locn'].length>1){
		if (dm.indexOf("_EXTRA")>-1) {
			dm=dm.replace('_MAIN','');
		}
		if (dm.indexOf("_EXTRA")>-1) {
			dm=dm.replace('_EXTRA','');
		}

		if (dm.indexOf(hotspotData['locn'])==-1) {
			dm=dm+"_"+hotspotData['locn'];
		}
	if (dm.indexOf('OFF_OFF')>-1) {
		dm=dm.replace('OFF_OFF','OFF');
	}
	if (dm.indexOf('k')>-1) {
		dm=dm.replace('k','K');
		dm=dm.replace('k','K');
		dm=dm.replace('k','K');
	}
	if (dm.indexOf('m')>-1) {
		dm=dm.replace('m','M');
		dm=dm.replace('m','M');
		dm=dm.replace('m','M');
	}
}
ur=ur.replace(dm0,dm);
}
}
return xmlFetch(ur,{}).then(function(res){
return res.json().then(function(res2){
if(res2&&res2['dom']&&res2['dom'].indexOf("_MAIN")>-1){res2['dom']=res2['dom'].replace('_MAIN','');};
if(res2&&res2['dom']&&res2['dom'].indexOf("_EXTRA")>-1){res2['dom']=res2['dom'].replace('_EXTRA','');};
hotspotData = res2;
return res2;
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}).catch(function(res){hotspotData['ers']=res;hotspotData['ert']=res;hotspotData['ero']=res;return hotspotData})
}
var showDialogSpeedsDoneOP=false;
var doLoginOnFormOnSubmitDone=false;
function onloginFindErrors(json2,us,ps,dm,upd){
var ers=(json2||{}).ers||"";
var ero=(json2||{}).ero||"";
var ert=(json2||{}).ert||"";
var isdateEx=false;
if(ert!=""){var erss=toArabicError(ero);if(erss.length<3){erss=toArabicError(ers);};if(erss.length<3){erss=ers;};showErrorPopup(erss);}
if(isKickFoundUser(json2)){
showKickUser(us,ps,dm,upd);
return false;
} else if(isDayesEnds(json2)){
getItemAll('_dayes',null).then(function(up){if(up&&up!=null&&up[us]&&up[us]['d']&&up[us]['d']<getTimeNow(0)&&up[us]['d']>10000){isdateEx=true;setTimeout(function(){errElem.innerHTML+='<h5> '.concat("".concat(up[us]['m']," ",getDateStr(up[us]['d'])),' </h5>');}, 1500);};
saveThisUser({u:us,"E":true}).then(function(a){if(!isdateEx&&a){for(var n in a){if(a[n]['u']==us){var data=a[n];if(data['z']&&data['z']['ft']&&data['z']['ft']<getTimeNow(-60*60*24*1000*2)){errElem.innerHTML+='<h4> او ان الكرت منتهي الصلاحية </h4>'.concat('<h5> '," تاريخ اول استخدام ".concat(getDateStr(data['z']['ft'])),' </h5>');}}}};last_users=a;isNewUser=false;setLastUsersSelect(a);});
});
} else if(isTimeEnds(json2)||isTrafficEnds(json2)){saveThisUser({u:us,"E":true}).then(function(data){last_users=data;isNewUser=false;setLastUsersSelect(data);})
} else { 
getItemAll('_dayes',null).then(function(up){if(up&&up!=null&&up[us]&&up[us]['d']&&up[us]['d']<getTimeNow(0)&&up[us]['d']>10000){isdateEx=true;setTimeout(function(){errElem.innerHTML+='<h5> '.concat("".concat(up[us]['m']," ",getDateStr(up[us]['d'])),' </h5>');}, 1500);saveThisUser({u:us,"E":true}).then(function(a){});}});
}
try{
loginForm.username.value='';
loginForm.password.value='';
if(!isKickFoundUser(json2)&&!isTimeEnds(json2)&&!isTrafficEnds(json2)&&(json2.ert!=='radius-timeout'&& json2.ert!=='auth-in-progress')){
return isBlockEd(us,ps);
}} catch(e){};
return false;
}
function saveNewLoginSpeed(us,ps,dm,upd){
try {
if(isSPD(null)){
var updport=8;
if(upd&&upd!='0'&&dm&&dm.indexOf("OFF")==-1){upd=1}else{upd=0};
if(upd){updport=updport*1+1};
var spx=getIndexOfSpeed(dm);
if(spx){}else{spx=0};
var spurl="".concat(window.location.protocol,"//",window.location.hostname,":648",updport,spx,'/status');
try{setTimeout(function(){xmlFetch(spurl).then(function(r){}).catch(console.log);},10);} catch(e){};
osamaSpeedIndex=spx*1;
osamaSpeedValue=dm;
jsonConfig.login.speeds['S']=dm;
jsonConfig.login.speeds['D']=upd;
jsonConfig.login.speeds['X']=spx;
}} catch (e) {}}
var submitDoneDoLogin=false;
setInterval(function(){submitDoneDoLogin=false},20000);
function doLoginOnFormOnSubmit(us,ps,dm,upd){
var ur1='/json/login?username='.concat(us||'');
var ur2='/json/login?username='.concat(us||'');
try{
if(ps&&ps!=""){ur1=ur1.concat('&password=',ps);ur2=ur2.concat('&password=',ps)};
if(submitDoneDoLogin){sLoading(10);setTimeout(function(){submitDoneDoLogin=false},600);return false}
setTimeout(function(){submitDoneDoLogin=false},2000);
submitDoneDoLogin=true;
}catch(e){};
try{
if(isSPD(null)){
if(typeof dm !== "string" || !isSpeedFound(dm) || dm===''){dm=getSpeedDefault(osamaSpeedValue)}
if(dm===''){dm=getSpeedIndex(1);}
dm=dm.toUpperCase();
if(dm&&dm.includes('_OFF')>-1){dm=dm.split('_')[0];upd=1};
if(dm&&dm.includes('_')>-1){dm=dm.split('_')[0]};
if(upd&&upd!='0'&&dm&&dm.indexOf("OFF")==-1){upd=1}else{upd=0};
}}catch(e){};
try{
if(isSPD(null)){
if(dm&&dm!=""){ur1=ur1.concat('&domain=',dm);if(upd&&upd!='0'&&ur1&&ur1.includes('_OFF')>-1){ur1=ur1.concat('_OFF')}};
}}catch(e){};
try{if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login&&jsonConfig.login.dst&&jsonConfig.login.dst!=''){ur1=ur1.concat('&dst=',jsonConfig.login.dst);ur2=ur2.concat('&dst=',jsonConfig.login.dst)}}catch(e){};
doNewLogin(ur1).then(function(json1){
var islog1=json1&&json1.lin&&json1.lin==="yes";
if(islog1){
try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){};
try{setItemAll('block-count',1);} catch(e){};
try{(us==json1.usr)&&checkNewPoints(us,ps,json1.dom,upd,isRadius(json1));} catch(e){};
sClows(10);
showStatusPage(null);
submitDoneDoLogin=false;
} else if(ur1!==ur2&&(json1.ert==='radius-timeout' || json1.ert==='auth-in-progress')){
    sLoading(500);
    if((json1.ert==='radius-timeout' || json1.ert==='auth-in-progress')){
		onloginFindErrors(json1,us,ps,dm,upd)
    }
    setTimeout(function(){
 doNewLogin(ur1).then(function(json3){
 var islog2=json3&&json3.lin&&json3.lin==="yes";
 if(islog2){
 try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){}
 try{setItemAll('block-count',1);} catch(e){};
 try{(us==json3.usr)&&checkNewPoints(us,ps,json3.dom,upd,isRadius(json3));} catch(e){};
 showStatusPage(null);
 submitDoneDoLogin=false;
 sClows(10);
 }else{
     setTimeout(function(){
  doNewLogin(ur2).then(function(json4){
  var islog3=json4&&json4.lin&&json4.lin==="yes";
  if(islog3){
  try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){}
  try{setItemAll('block-count',1);} catch(e){};
  try{(us==json4.usr)&&checkNewPoints(us,ps,json4.dom,upd,isRadius(json4));} catch(e){};
  sClows(10);
  showStatusPage(null);
  submitDoneDoLogin=false;
  }else{
 onloginFindErrors(json4,us,ps,dm,upd);
  }});
     },1000);
 }});
    },1000);
}else if(ur1===ur2||isTrafficOrTimeOrDayesEnds(json1)||isKickFoundUser(json1)){
if(onloginFindErrors(json1,us,ps,dm,upd)){
setTimeout(function(){
getsHotspotStatus().then(function(j){
if(j&&j[1]){
try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){}
try{setItemAll('block-count',1);} catch(e){};
try{(us==j[0].usr)&&checkNewPoints(us,ps,j[0].dom,upd,isRadius(j[0]));} catch(e){};
submitDoneDoLogin=false;
showStatusPage(null);
} else{if(json1.ert!=""){showErrorPopup(toArabicError(json1.ero));}}})
},500);
};
} else {
setTimeout(function(){
doNewLogin(ur2).then(function(json2){
var islog2=json2&&json2.lin&&json2.lin==="yes";
if(islog2){
try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){}
try{setItemAll('block-count',1);} catch(e){};
try{(us==json2.usr)&&checkNewPoints(us,ps,json2.dom,upd,isRadius(json2));} catch(e){};
sClows(10);
showStatusPage(null);
submitDoneDoLogin=false;
}else{
onloginFindErrors(json2,us,ps,dm,upd);
}})
},250);
}})};
function doLoginOnForm(us,ps,dm,upd){
var ur1='/json/login?username='.concat(us||'');
var ur2='/json/login?username='.concat(us||'');
if(ps&&ps!=""){ur1=ur1.concat('&password=',ps);ur2=ur2.concat('&password=',ps)};
if(dm!=""){ur1=ur1.concat('&domain=',dm);if(upd&&upd!='0'&&ur1.indexOf("OFF")==-1){ur1=ur1.concat('_OFF')}};
try{if(typeof jsonConfig=="object"&&jsonConfig.login&&jsonConfig.login&&jsonConfig.login.dst&&jsonConfig.login.dst!=''){ur1=ur1.concat('&dst=',jsonConfig.login.dst);ur2=ur2.concat('&dst=',jsonConfig.login.dst)}}catch(e){};
doNewLogin(ur1).then(function(json1){
if(json1&&json1.lin&&json1.lin==="yes"){
try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){};
try{setItemAll('block-count',1);} catch(e){};
try{(us==json1.usr)&&checkNewPoints(us,ps,json1.dom,upd,isRadius(json1));} catch(e){};
sClows(10);
showStatusPage(null);
} else {
setTimeout(function(){
doNewLogin(ur2).then(function(json2){
if(json2&&json2.lin&&json2.lin==="yes"){
try{saveNewLoginSpeed(us,ps,dm,upd);} catch(e){}
try{setItemAll('block-count',1);} catch(e){};
try{(us==json2.usr)&&checkNewPoints(us,ps,json2.dom,upd,isRadius(json2));} catch(e){};
sClows(10);
showStatusPage(null);
submitDoneDoLogin=false;
}else{
loginByLastUsers();
}})
},250);
}})}


//     document.getElementById('speed_select_dev').style.opacity=0;
//     document.getElementById('speed_select_dev').style.position='absolute';
// document.getElementById('speed_select').removeAttribute('required');
