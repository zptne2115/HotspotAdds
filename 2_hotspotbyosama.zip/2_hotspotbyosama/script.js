/* Extra 5G keeps this layer intentionally small and offline-safe. */
const extra5gConfig = {
  packages: [
    { price: 100, balance: '500 ميجا', hours: 4, validity: 'يومان' },
    { price: 150, balance: '700 ميجا', hours: 6, validity: '3 أيام' },
    { price: 250, balance: '1.5 جيجا', hours: 10, validity: '4 أيام' }
  ],
  links: {
    entertainment: null,
    live: null,
    whatsapp: null
  }
};

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
document.documentElement.classList.add('js-enabled');
const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && !prefersReducedMotion) {
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      currentObserver.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -28px' });
  revealItems.forEach((item) => observer.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add('is-visible'));
}

document.querySelectorAll('.faq-item button').forEach((button) => {
  button.addEventListener('click', () => {
    const item = button.closest('.faq-item');
    const answer = document.getElementById(button.getAttribute('aria-controls'));
    const willOpen = button.getAttribute('aria-expanded') !== 'true';
    document.querySelectorAll('.faq-item').forEach((otherItem) => {
      const otherButton = otherItem.querySelector('button');
      const otherAnswer = otherItem.querySelector('.faq-answer');
      otherItem.classList.remove('is-open');
      otherButton.setAttribute('aria-expanded', 'false');
      otherAnswer.hidden = true;
    });
    if (willOpen) {
      item.classList.add('is-open');
      button.setAttribute('aria-expanded', 'true');
      answer.hidden = false;
    }
  });
});

document.querySelectorAll('.placeholder-cta').forEach((link) => {
  link.addEventListener('click', (event) => {
    const destination = link.dataset.placeholderLink || 'الخدمة';
    if (extra5gConfig.links.entertainment || extra5gConfig.links.live || extra5gConfig.links.whatsapp) return;
    event.preventDefault();
    const status = document.getElementById('contact-status');
    if (status) {
      status.textContent = `سيتم تفعيل رابط ${destination} عند توفره.`;
      window.setTimeout(() => { status.textContent = ''; }, 4200);
    } else {
      link.setAttribute('aria-label', `سيتم تفعيل رابط ${destination} عند توفره`);
    }
  });
});

// Keep anchor links usable even in very old embedded hotspot browsers.
document.querySelectorAll('a[href^="#"]:not(.placeholder-cta)').forEach((link) => {
  link.addEventListener('click', (event) => {
    const target = document.querySelector(link.getAttribute('href'));
    if (!target) return;
    event.preventDefault();
    target.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'start' });
  });
});
